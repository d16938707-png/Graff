import 'package:flutter/material.dart';

import 'ui/boot_screen.dart';

void main() => runApp(const GraffApp());

class GraffApp extends StatelessWidget {
  const GraffApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'GRAFF',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          colorSchemeSeed: const Color(0xFF7C4DFF),
          useMaterial3: true,
        ),
        home: const BootScreen(),
      );
}
