import 'dart:async';

import 'package:flutter/material.dart';

import '../core/graff_core.dart';
import '../core/models.dart';

class ChatScreen extends StatefulWidget {
  final GraffCore core;
  final Contact contact;
  const ChatScreen({super.key, required this.core, required this.contact});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _ctl = TextEditingController();
  List<StoredMessage> _msgs = [];
  StreamSubscription<ChatEvent>? _sub;
  Timer? _poll;

  @override
  void initState() {
    super.initState();
    _reload();
    _sub = widget.core.events.listen((e) {
      if (e.contactId == widget.contact.id) _reload();
    });
    // refreshes the "queued -> delivered" marks of outgoing messages
    _poll = Timer.periodic(const Duration(seconds: 3), (_) => _reload());
  }

  @override
  void dispose() {
    _sub?.cancel();
    _poll?.cancel();
    super.dispose();
  }

  Future<void> _reload() async {
    final m = await widget.core.history(widget.contact.id);
    if (mounted) setState(() => _msgs = m);
  }

  Future<void> _send() async {
    final t = _ctl.text.trim();
    if (t.isEmpty) return;
    _ctl.clear();
    await widget.core.sendText(widget.contact.id, t);
    await _reload();
  }

  Future<void> _safety() async {
    final n = await widget.core.safetyNumber(widget.contact.id);
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Код безопасности'),
        content: Text('Сверьте с контактом лично:\n\n$n'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.contact.name),
        actions: [
          IconButton(
              tooltip: 'Код безопасности',
              onPressed: _safety,
              icon: const Icon(Icons.verified_user)),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              padding: const EdgeInsets.all(12),
              itemCount: _msgs.length,
              itemBuilder: (_, i) {
                final m = _msgs[_msgs.length - 1 - i];
                return Align(
                  alignment:
                      m.outgoing ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 3),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    constraints: BoxConstraints(
                        maxWidth: MediaQuery.of(context).size.width * 0.75),
                    decoration: BoxDecoration(
                      color: m.outgoing
                          ? Theme.of(context).colorScheme.primaryContainer
                          : Theme.of(context).colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(m.text),
                        if (m.outgoing)
                          Text(m.status == 'sent' ? '✓ доставлено' : '… в очереди',
                              style: const TextStyle(fontSize: 10)),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _ctl,
                      onSubmitted: (_) => _send(),
                      decoration: const InputDecoration(
                          hintText: 'Сообщение',
                          border: OutlineInputBorder()),
                    ),
                  ),
                  IconButton(onPressed: _send, icon: const Icon(Icons.send)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
