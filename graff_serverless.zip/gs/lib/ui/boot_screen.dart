import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import '../core/graff_core.dart';
import '../core/storage/blob_store.dart';
import '../core/storage/vault.dart';
import '../core/transport/tcp_transport.dart';
import '../core/transport/tor_session.dart';
import '../core/transport/transport.dart';
import '../platform/android_tor_backend.dart';
import 'home_screen.dart';

/// Release builds always go through Tor. Debug builds use plain LAN delivery
/// unless started with --dart-define=GRAFF_TOR=true.
const bool _useTor = bool.fromEnvironment('GRAFF_TOR', defaultValue: kReleaseMode);

class BootScreen extends StatefulWidget {
  const BootScreen({super.key});
  @override
  State<BootScreen> createState() => _BootScreenState();
}

class _BootScreenState extends State<BootScreen> {
  final _pass = TextEditingController();
  final _name = TextEditingController();
  FileBlobStore? _store;
  bool? _exists;
  bool _busy = false;
  String? _error;
  String? _status;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final base = await getApplicationSupportDirectory();
    final store = FileBlobStore(Directory('${base.path}/graff_vault'));
    final exists = await Vault.exists(store);
    if (mounted) setState(() {
      _store = store;
      _exists = exists;
    });
  }

  Future<void> _go() async {
    final store = _store!;
    final pass = _pass.text;
    if (pass.length < 8) {
      setState(() => _error = 'Парольная фраза: минимум 8 символов');
      return;
    }
    if (!_exists! && _name.text.trim().isEmpty) {
      setState(() => _error = 'Введите имя (его увидят только ваши контакты)');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final vault = _exists!
          ? await Vault.unlock(store, pass)
          : await Vault.create(store, pass);
      final Transport transport;
      TorSession? tor;
      if (_useTor) {
        if (mounted) setState(() => _status = 'Подключение к Tor…');
        tor = await TorSession.start(
          backend: AndroidTorBackend(),
          vault: vault,
          onProgress: (p) {
            if (mounted) setState(() => _status = 'Подключение к Tor… $p%');
          },
        );
        transport = tor.transport;
      } else {
        final lan = await findLanAddress();
        transport = TcpTransport(
          allowDirect: true,
          advertise: lan == null ? null : '$lan:7777',
        );
      }
      final core = await GraffCore.open(
        vault: vault,
        transport: transport,
        newIdentityName: _exists! ? null : _name.text.trim(),
        onClose: tor?.close,
      );
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => HomeScreen(core: core)));
    } on WrongPassphrase {
      setState(() {
        _busy = false;
        _status = null;
        _error = 'Неверная парольная фраза';
      });
    } catch (e) {
      setState(() {
        _busy = false;
        _status = null;
        _error = 'Ошибка: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_exists == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('GRAFF',
                      style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(
                    _exists!
                        ? 'Введите парольную фразу'
                        : 'Без серверов, номеров и почты. Всё хранится только на этом устройстве. '
                            'Если забудете фразу — восстановить данные невозможно.',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  if (!_exists!) ...[
                    TextField(
                      controller: _name,
                      decoration: const InputDecoration(
                          labelText: 'Имя', border: OutlineInputBorder()),
                    ),
                    const SizedBox(height: 12),
                  ],
                  TextField(
                    controller: _pass,
                    obscureText: true,
                    onSubmitted: (_) => _go(),
                    decoration: const InputDecoration(
                        labelText: 'Парольная фраза',
                        border: OutlineInputBorder()),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(_error!, style: const TextStyle(color: Colors.redAccent)),
                  ],
                  if (_status != null) ...[
                    const SizedBox(height: 12),
                    Text(_status!),
                  ],
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: _busy ? null : _go,
                    child: _busy
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : Text(_exists! ? 'Открыть' : 'Создать'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
