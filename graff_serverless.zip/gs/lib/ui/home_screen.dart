import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/graff_core.dart';
import '../core/models.dart';
import 'boot_screen.dart';
import 'chat_screen.dart';

class HomeScreen extends StatefulWidget {
  final GraffCore core;
  const HomeScreen({super.key, required this.core});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  GraffCore get core => widget.core;

  void _showMyLink() {
    final link = core.myLink();
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Моя контактная ссылка'),
        content: SelectableText(link),
        actions: [
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: link));
              Navigator.pop(context);
            },
            child: const Text('Копировать'),
          ),
        ],
      ),
    );
  }

  Future<void> _addContact() async {
    final ctl = TextEditingController();
    final link = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Добавить контакт'),
        content: TextField(
          controller: ctl,
          decoration: const InputDecoration(hintText: 'graff://c/…'),
          maxLines: 4,
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, ctl.text),
              child: const Text('Добавить')),
        ],
      ),
    );
    if (link == null || link.trim().isEmpty) return;
    try {
      await core.addContact(link);
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Не удалось: $e')));
      }
    }
  }

  Future<void> _panic() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Стереть всё?'),
        content: const Text(
            'Удалит ключи, контакты и переписку на этом устройстве. Это необратимо.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Отмена')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Стереть')),
        ],
      ),
    );
    if (ok != true) return;
    await core.panicWipe();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const BootScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final List<Contact> list = core.contacts;
    return Scaffold(
      appBar: AppBar(
        title: Text('GRAFF · ${core.identity.name}'),
        actions: [
          IconButton(
              tooltip: 'Моя ссылка',
              onPressed: _showMyLink,
              icon: const Icon(Icons.qr_code)),
          IconButton(
              tooltip: 'Стереть всё',
              onPressed: _panic,
              icon: const Icon(Icons.delete_forever)),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addContact,
        child: const Icon(Icons.person_add),
      ),
      body: list.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Контактов нет. Обменяйтесь ссылками лично (QR / мессенджер / NFC): '
                  'сервера, который знакомит людей, здесь нет.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView(
              children: [
                for (final c in list)
                  ListTile(
                    leading: CircleAvatar(child: Text(c.name.characters.first)),
                    title: Text(c.name),
                    subtitle: Text(c.id),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => ChatScreen(core: core, contact: c))),
                  ),
              ],
            ),
    );
  }
}
