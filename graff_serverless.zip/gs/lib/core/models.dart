import 'crypto/bundle.dart';

class Contact {
  final String id;
  String name;
  final ContactBundle bundle;
  Contact(this.id, this.name, this.bundle);
}

class StoredMessage {
  final String id;
  final bool outgoing;
  final String text;
  final int ts; // ms since epoch, set by the sender
  String status; // queued | sent | received

  StoredMessage({
    required this.id,
    required this.outgoing,
    required this.text,
    required this.ts,
    required this.status,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'o': outgoing,
        't': text,
        'ts': ts,
        's': status,
      };

  factory StoredMessage.fromJson(Map<String, dynamic> j) => StoredMessage(
        id: j['id'] as String,
        outgoing: j['o'] as bool,
        text: j['t'] as String,
        ts: j['ts'] as int,
        status: j['s'] as String,
      );
}

class ChatEvent {
  final String contactId;
  final StoredMessage message;
  ChatEvent(this.contactId, this.message);
}
