import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'crypto/aead.dart';
import 'crypto/bundle.dart';
import 'crypto/bytes.dart';
import 'crypto/identity.dart';
import 'crypto/kdf.dart';
import 'crypto/padding.dart';
import 'crypto/ratchet.dart';
import 'crypto/x3dh.dart';
import 'models.dart';
import 'storage/vault.dart';
import 'transport/transport.dart';

const int _frameInit = 0x01; // ek(32) || ratchet message
const int _frameMsg = 0x02; // ratchet message

class _Mutex {
  Future<void> _tail = Future<void>.value();
  Future<T> run<T>(Future<T> Function() f) {
    final c = Completer<T>();
    final prev = _tail;
    _tail = c.future.then((_) {}, onError: (_) {});
    prev.then((_) async {
      try {
        c.complete(await f());
      } catch (e, s) {
        c.completeError(e, s);
      }
    });
    return c.future;
  }
}

class _Session {
  DoubleRatchet dr;
  Uint8List? initEk; // initiator: keep prefixing frames until the peer answers
  Uint8List? peerEk; // responder: ek of the handshake that created the session
  // ids of messages sent before the peer ever answered (may need re-sending
  // if the peer's handshake wins a simultaneous start)
  List<String> firstFlight;
  _Session(this.dr, {this.initEk, this.peerEk, List<String>? firstFlight})
      : firstFlight = firstFlight ?? [];

  Map<String, dynamic> toJson() => {
        'dr': dr.toJson(),
        'initEk': initEk == null ? null : b64u(initEk!),
        'peerEk': peerEk == null ? null : b64u(peerEk!),
        'ff': firstFlight,
      };

  factory _Session.fromJson(Map<String, dynamic> j) => _Session(
        DoubleRatchet.fromJson(j['dr'] as Map<String, dynamic>),
        initEk: j['initEk'] == null ? null : unb64u(j['initEk'] as String),
        peerEk: j['peerEk'] == null ? null : unb64u(j['peerEk'] as String),
        firstFlight: ((j['ff'] ?? <dynamic>[]) as List).cast<String>().toList(),
      );
}

/// The whole messenger without a server: identity, contacts, sessions and
/// history live only in the encrypted [Vault] on this device.
class GraffCore {
  final Vault _vault;
  final Transport _transport;
  final Identity identity;
  final Future<void> Function()? _onClose;

  final Map<String, Contact> _contacts = {};
  final _events = StreamController<ChatEvent>.broadcast();
  final _lock = _Mutex();
  StreamSubscription<Uint8List>? _sub;
  Timer? _timer;
  bool _flushing = false;

  GraffCore._(this._vault, this._transport, this.identity, this._onClose);

  Stream<ChatEvent> get events => _events.stream;
  List<Contact> get contacts => _contacts.values.toList();

  static Future<GraffCore> open({
    required Vault vault,
    required Transport transport,
    String? newIdentityName,
    Duration flushEvery = const Duration(seconds: 20),
    Future<void> Function()? onClose, // e.g. TorSession.close
  }) async {
    final j = await vault.getJson('identity');
    Identity id;
    if (j != null) {
      id = await Identity.fromJson(j as Map<String, dynamic>);
    } else {
      if (newIdentityName == null) {
        throw StateError('identity missing; provide newIdentityName');
      }
      id = await Identity.generate(newIdentityName);
      await vault.putJson('identity', id.toJson());
    }
    final core = GraffCore._(vault, transport, id, onClose);
    await core._loadContacts();
    await transport.start();
    core._sub = transport.incoming.listen(core._onFrame);
    core._timer = Timer.periodic(flushEvery, (_) => core.flushOutbox());
    unawaited(core.flushOutbox());
    return core;
  }

  Future<void> close() async {
    _timer?.cancel();
    await _sub?.cancel();
    await _transport.stop();
    await _events.close();
    await _onClose?.call();
  }

  /// Irreversibly destroys everything stored on this device.
  Future<void> panicWipe() async {
    await close();
    await _vault.wipe();
  }

  // ---------------------------------------------------------------- contacts

  String myLink() {
    final a = _transport.localAddress;
    return ContactBundle.fromIdentity(identity, onion: a.onion, ble: a.ble)
        .toLink();
  }

  Future<Contact> addContact(String link) async {
    final b = ContactBundle.fromLink(link);
    if (!await b.verify()) throw const FormatException('bad signature');
    final id = await b.id();
    if (id == identity.id) throw StateError('that is your own link');
    final c = Contact(id, b.name, b);
    _contacts[id] = c;
    await _saveContacts();
    return c;
  }

  Future<void> removeContact(String id) => _lock.run(() async {
        _contacts.remove(id);
        await _saveContacts();
        await _vault.delete('session/$id');
        await _vault.delete('chat/$id');
      });

  Future<void> _saveContacts() => _vault.putJson('contacts', {
        'items': _contacts.values
            .map((c) => {'name': c.name, 'link': c.bundle.toLink()})
            .toList(),
      });

  Future<void> _loadContacts() async {
    final j = await _vault.getJson('contacts');
    if (j == null) return;
    for (final e in (j['items'] as List)) {
      final b = ContactBundle.fromLink(e['link'] as String);
      final id = await b.id();
      _contacts[id] = Contact(id, e['name'] as String, b);
    }
  }

  /// Compare these digits with your contact in person / over another channel
  /// to rule out a man-in-the-middle swapping the links.
  Future<String> safetyNumber(String contactId) async {
    final c = _contacts[contactId]!;
    final mine = concatBytes([identity.edPub, identity.xPub]);
    final theirs = concatBytes([c.bundle.edPub, c.bundle.xPub]);
    final h = compareBytes(mine, theirs) <= 0
        ? await sha256(concatBytes([mine, theirs]))
        : await sha256(concatBytes([theirs, mine]));
    final groups = <String>[];
    for (var i = 0; i < 8; i++) {
      groups.add((readU32be(h, i * 4) % 100000).toString().padLeft(5, '0'));
    }
    return groups.join(' ');
  }

  // ---------------------------------------------------------------- sessions

  Future<_Session?> _loadSession(String id) async {
    final j = await _vault.getJson('session/$id');
    return j == null ? null : _Session.fromJson(j as Map<String, dynamic>);
  }

  Future<void> _saveSession(String id, _Session s) =>
      _vault.putJson('session/$id', s.toJson());

  // ----------------------------------------------------------------- sending

  Future<StoredMessage> sendText(String contactId, String text) async {
    final msg = await _lock.run(() async {
      final c = _contacts[contactId];
      if (c == null) throw StateError('unknown contact');
      var s = await _loadSession(contactId);
      if (s == null) {
        final hs = await x3dhInitiate(me: identity, them: c.bundle);
        final dr =
            await DoubleRatchet.initSender(hs.sk, hs.ad, c.bundle.spkPub);
        s = _Session(dr, initEk: hs.ekPub);
      }
      final m = StoredMessage(
        id: toHex(randomBytes(8)),
        outgoing: true,
        text: text,
        ts: DateTime.now().millisecondsSinceEpoch,
        status: 'queued',
      );
      if (s.initEk != null) s.firstFlight.add(m.id);
      final entry = await _seal(contactId, s, m);
      await _saveSession(contactId, s);
      await _appendMessage(contactId, m);
      final box = await _loadOutbox();
      box.add(entry);
      await _saveOutbox(box);
      return m;
    });
    unawaited(flushOutbox());
    return msg;
  }


  /// Encrypts [m] under [s] and returns the outbox entry for it.
  Future<Map<String, dynamic>> _seal(
      String contactId, _Session s, StoredMessage m) async {
    final payload = padPlain(Uint8List.fromList(
        utf8.encode(jsonEncode({'v': 1, 'id': m.id, 't': m.text, 'ts': m.ts}))));
    final enc = await s.dr.encrypt(payload);
    final ek = s.initEk;
    final frame = ek != null
        ? concatBytes([
            [_frameInit],
            ek,
            enc
          ])
        : concatBytes([
            [_frameMsg],
            enc
          ]);
    // 'e' identifies this exact frame, so a re-queued copy of the same message
    // is never confused with the one currently being sent.
    return {'c': contactId, 'm': m.id, 'f': b64u(frame), 'e': toHex(randomBytes(8))};
  }

  /// We lost a simultaneous-start tie-break and adopted the peer's session.
  /// Our first-flight messages were sent under the discarded session and the
  /// peer dropped them (even if the transport acknowledged), so send them
  /// again under the new one and purge stale frames from the outbox.
  Future<void> _requeue(Contact c, List<String> ids) async {
    final s = await _loadSession(c.id);
    if (s == null) return;
    final box = await _loadOutbox()
      ..removeWhere((e) => e['c'] == c.id);
    final hist = await history(c.id);
    for (final id in ids) {
      for (final m in hist) {
        if (m.id == id && m.outgoing) {
          m.status = 'queued';
          box.add(await _seal(c.id, s, m));
        }
      }
    }
    await _saveSession(c.id, s);
    await _saveOutbox(box);
    await _vault.putJson(
        'chat/${c.id}', hist.map((e) => e.toJson()).toList());
  }

  Future<List<Map<String, dynamic>>> _loadOutbox() async {
    final j = await _vault.getJson('outbox');
    if (j == null) return [];
    return (j['items'] as List).cast<Map<String, dynamic>>().toList();
  }

  Future<void> _saveOutbox(List<Map<String, dynamic>> items) =>
      _vault.putJson('outbox', {'items': items});

  /// Serverless means no store-and-forward: a message leaves the outbox only
  /// when the recipient's device acknowledged it. Retried periodically.
  Future<void> flushOutbox() async {
    if (_flushing) return;
    _flushing = true;
    try {
      final snapshot = await _lock.run(_loadOutbox);
      final sentEntries = <Map<String, dynamic>>[];
      final blocked = <String>{};
      for (final e in snapshot) {
        final cid = e['c'] as String;
        if (blocked.contains(cid)) continue; // keep per-contact order
        final c = _contacts[cid];
        if (c == null) continue;
        final ok = await _transport.send(
          PeerAddress(onion: c.bundle.onion, ble: c.bundle.ble),
          unb64u(e['f'] as String),
        );
        if (ok) {
          sentEntries.add(e);
        } else {
          blocked.add(cid);
        }
      }
      if (sentEntries.isEmpty) return;
      await _lock.run(() async {
        final sentIds = sentEntries.map((e) => e['e'] as String).toSet();
        final box = await _loadOutbox();
        box.removeWhere((e) => sentIds.contains(e['e']));
        await _saveOutbox(box);
        for (final e in sentEntries) {
          final cid = e['c'] as String;
          final mid = e['m'] as String;
          // a re-queued copy of this message may still be waiting
          final stillQueued = box.any((x) => x['c'] == cid && x['m'] == mid);
          if (!stillQueued) await _setStatus(cid, mid, 'sent');
        }
      });
    } finally {
      _flushing = false;
    }
  }

  // --------------------------------------------------------------- receiving

  void _onFrame(Uint8List frame) {
    unawaited(_lock.run(() => _handleFrame(frame)).catchError((_) {}));
  }

  Future<void> _handleFrame(Uint8List frame) async {
    if (frame.isEmpty) return;
    if (frame[0] == _frameInit && frame.length > 33) {
      await _handleInit(
        Uint8List.fromList(frame.sublist(1, 33)),
        Uint8List.fromList(frame.sublist(33)),
      );
    } else if (frame[0] == _frameMsg && frame.length > 1) {
      await _handleMsg(Uint8List.fromList(frame.sublist(1)));
    }
    // anything else is dropped silently: no error replies, nothing to probe
  }

  Future<void> _handleMsg(Uint8List msg) async {
    // The frame carries no sender id (anonymity), so try each session.
    for (final c in _contacts.values) {
      final s = await _loadSession(c.id);
      if (s == null) continue;
      try {
        await _accept(c, s, msg);
        return;
      } on DecryptionFailure {
        continue;
      } on FormatException {
        continue;
      }
    }
  }

  Future<void> _handleInit(Uint8List ek, Uint8List msg) async {
    // 1) a retransmitted INIT of a session we already hold
    for (final c in _contacts.values) {
      final s = await _loadSession(c.id);
      if (s?.peerEk != null && constantTimeEquals(s!.peerEk!, ek)) {
        try {
          await _accept(c, s, msg);
        } on DecryptionFailure {
          // replay or corrupt: ignore
        }
        return;
      }
    }
    // 2) a new session: the initiator's identity is hidden inside the
    //    handshake, so try each known contact. Strangers are dropped.
    //    An existing session is replaced only in one case: we both started
    //    at once and we lose the tie-break (larger id adopts the other's).
    //    Everything else (e.g. a delayed old INIT) must not reset a session.
    for (final c in _contacts.values) {
      final existing = await _loadSession(c.id);
      var resend = <String>[];
      if (existing != null) {
        final iLose =
            existing.initEk != null && identity.id.compareTo(c.id) > 0;
        if (!iLose) continue;
        resend = List<String>.of(existing.firstFlight);
      }
      final hs = await x3dhRespond(me: identity, initiator: c.bundle, ekPub: ek);
      final s = _Session(
        DoubleRatchet.initReceiver(
            hs.sk, hs.ad, identity.spkSeed, identity.spkPub),
        peerEk: ek,
      );
      try {
        await _accept(c, s, msg);
        if (resend.isNotEmpty) await _requeue(c, resend);
        return;
      } on DecryptionFailure {
        continue;
      } on FormatException {
        continue;
      }
    }
  }

  /// Decrypts, then persists session + message, then notifies the UI.
  Future<void> _accept(Contact c, _Session s, Uint8List msg) async {
    final padded = await s.dr.decrypt(msg); // atomic; throws on forgery
    final p = jsonDecode(utf8.decode(unpadPlain(padded))) as Map<String, dynamic>;
    s.initEk = null; // the peer clearly holds the session now
    s.firstFlight.clear();
    await _saveSession(c.id, s);
    final m = StoredMessage(
      id: p['id'] as String,
      outgoing: false,
      text: p['t'] as String,
      ts: p['ts'] as int,
      status: 'received',
    );
    await _appendMessage(c.id, m);
    if (!_events.isClosed) _events.add(ChatEvent(c.id, m));
  }

  // ----------------------------------------------------------------- history

  Future<List<StoredMessage>> history(String contactId) async {
    final j = await _vault.getJson('chat/$contactId');
    if (j == null) return [];
    return (j as List)
        .map((e) => StoredMessage.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> _appendMessage(String contactId, StoredMessage m) async {
    final list = await history(contactId);
    if (list.any((x) => x.id == m.id)) return;
    list.add(m);
    await _vault.putJson('chat/$contactId', list.map((e) => e.toJson()).toList());
  }

  Future<void> _setStatus(String contactId, String msgId, String status) async {
    final list = await history(contactId);
    for (final m in list) {
      if (m.id == msgId) m.status = status;
    }
    await _vault.putJson('chat/$contactId', list.map((e) => e.toJson()).toList());
  }
}
