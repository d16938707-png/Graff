import 'dart:io';
import 'dart:typed_data';

abstract class BlobStore {
  Future<Uint8List?> read(String name);
  Future<void> write(String name, Uint8List data);
  Future<void> remove(String name);
  Future<void> wipe();
}

class MemoryBlobStore implements BlobStore {
  final Map<String, Uint8List> blobs = {};
  @override
  Future<Uint8List?> read(String name) async => blobs[name];
  @override
  Future<void> write(String name, Uint8List data) async => blobs[name] = data;
  @override
  Future<void> remove(String name) async => blobs.remove(name);
  @override
  Future<void> wipe() async => blobs.clear();
}

class FileBlobStore implements BlobStore {
  final Directory dir;
  FileBlobStore(this.dir);

  File _f(String n) => File('${dir.path}/$n');

  @override
  Future<Uint8List?> read(String name) async {
    final f = _f(name);
    return await f.exists() ? await f.readAsBytes() : null;
  }

  @override
  Future<void> write(String name, Uint8List data) async {
    await dir.create(recursive: true);
    final tmp = File('${dir.path}/$name.tmp');
    await tmp.writeAsBytes(data, flush: true);
    await tmp.rename(_f(name).path); // atomic replace
  }

  @override
  Future<void> remove(String name) async {
    final f = _f(name);
    if (await f.exists()) await f.delete();
  }

  @override
  Future<void> wipe() async {
    if (await dir.exists()) await dir.delete(recursive: true);
  }
}
