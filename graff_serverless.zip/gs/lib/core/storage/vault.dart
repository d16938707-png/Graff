import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

import '../crypto/aead.dart';
import '../crypto/bytes.dart';
import '../crypto/kdf.dart';
import 'blob_store.dart';

class WrongPassphrase implements Exception {
  @override
  String toString() => 'WrongPassphrase';
}

class Argon2Params {
  final int memoryKiB, iterations, parallelism;
  const Argon2Params(this.memoryKiB, this.iterations, this.parallelism);

  /// Tunable: pure-Dart Argon2id is slower than native; raise on fast devices.
  static const standard = Argon2Params(32 * 1024, 3, 1);

  /// For unit tests only.
  static const fastForTests = Argon2Params(1024, 1, 1);
}

/// Everything on disk is XChaCha20-Poly1305 under keys derived from the
/// passphrase with Argon2id. File names are HMAC'd, so they leak neither
/// contact ids nor chat structure. Destroying `meta` (the salt) is a
/// cryptographic wipe even where flash storage can't be overwritten.
class Vault {
  static const _meta = 'meta';
  static const _check = '__check';
  static const _index = '__index';

  final BlobStore _store;
  final Uint8List _dataKey;
  final Uint8List _nameKey;
  final Set<String> _names;

  Vault._(this._store, this._dataKey, this._nameKey, this._names);

  static Future<bool> exists(BlobStore s) async => (await s.read(_meta)) != null;

  static Future<({Uint8List dataKey, Uint8List nameKey})> _keys(
    String passphrase,
    Uint8List salt,
    Argon2Params p,
  ) async {
    final alg = Argon2id(
      memory: p.memoryKiB,
      parallelism: p.parallelism,
      iterations: p.iterations,
      hashLength: 32,
    );
    final master = await alg.deriveKeyFromPassword(
      password: passphrase,
      nonce: salt,
    );
    final m = await master.extractBytes();
    return (
      dataKey: await hkdf(m, info: 'graff/vault/data/v1', length: 32),
      nameKey: await hkdf(m, info: 'graff/vault/name/v1', length: 32),
    );
  }

  static Future<Vault> create(
    BlobStore store,
    String passphrase, {
    Argon2Params params = Argon2Params.standard,
  }) async {
    if (await exists(store)) throw StateError('vault already exists');
    final salt = randomBytes(16);
    final k = await _keys(passphrase, salt, params);
    final v = Vault._(store, k.dataKey, k.nameKey, <String>{});
    await store.write(
      _meta,
      Uint8List.fromList(utf8.encode(jsonEncode({
        'v': 1,
        'salt': b64u(salt),
        'm': params.memoryKiB,
        'i': params.iterations,
        'p': params.parallelism,
      }))),
    );
    await v.putBytes(_check, Uint8List.fromList(utf8.encode('graff-ok')));
    return v;
  }

  static Future<Vault> unlock(BlobStore store, String passphrase) async {
    final raw = await store.read(_meta);
    if (raw == null) throw StateError('no vault');
    final j = jsonDecode(utf8.decode(raw)) as Map<String, dynamic>;
    final params = Argon2Params(j['m'] as int, j['i'] as int, j['p'] as int);
    final k = await _keys(passphrase, unb64u(j['salt'] as String), params);
    final v = Vault._(store, k.dataKey, k.nameKey, <String>{});
    final ok = await v._tryGet(_check);
    if (ok == null) throw WrongPassphrase();
    final idx = await v._tryGet(_index);
    if (idx != null) {
      v._names.addAll((jsonDecode(utf8.decode(idx)) as List).cast<String>());
    }
    return v;
  }

  Future<String> _phys(String logical) async =>
      toHex(await hmacSha256(_nameKey, utf8.encode(logical))).substring(0, 32);

  Future<Uint8List?> _tryGet(String logical) async {
    final blob = await _store.read(await _phys(logical));
    if (blob == null || blob.length < 1 + 24 + macLength || blob[0] != 1) {
      return null;
    }
    try {
      return await aeadOpen(
        xchacha20,
        _dataKey,
        blob.sublist(1, 25),
        blob.sublist(25),
        utf8.encode(logical), // binds the blob to its name
      );
    } on DecryptionFailure {
      return null;
    }
  }

  Future<void> putBytes(String logical, Uint8List data) async {
    final nonce = randomBytes(24);
    final sealed = await aeadSeal(
        xchacha20, _dataKey, nonce, data, utf8.encode(logical));
    await _store.write(
      await _phys(logical),
      concatBytes([
        [1],
        nonce,
        sealed
      ]),
    );
    if (logical != _check && logical != _index && _names.add(logical)) {
      await _writeIndex();
    }
  }

  Future<Uint8List?> getBytes(String logical) => _tryGet(logical);

  Future<void> putJson(String logical, Object json) =>
      putBytes(logical, Uint8List.fromList(utf8.encode(jsonEncode(json))));

  Future<dynamic> getJson(String logical) async {
    final b = await _tryGet(logical);
    return b == null ? null : jsonDecode(utf8.decode(b));
  }

  Future<void> delete(String logical) async {
    await _store.remove(await _phys(logical));
    if (_names.remove(logical)) await _writeIndex();
  }

  List<String> names(String prefix) =>
      _names.where((n) => n.startsWith(prefix)).toList()..sort();

  Future<void> _writeIndex() async {
    final nonce = randomBytes(24);
    final sealed = await aeadSeal(
      xchacha20,
      _dataKey,
      nonce,
      utf8.encode(jsonEncode(_names.toList())),
      utf8.encode(_index),
    );
    await _store.write(
      await _phys(_index),
      concatBytes([
        [1],
        nonce,
        sealed
      ]),
    );
  }

  /// Panic button: removes the files and forgets the keys.
  Future<void> wipe() async {
    await _store.wipe();
    _dataKey.fillRange(0, _dataKey.length, 0);
    _nameKey.fillRange(0, _nameKey.length, 0);
    _names.clear();
  }
}
