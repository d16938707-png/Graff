import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import '../crypto/bytes.dart';
import 'transport.dart';

/// Exactly-N-bytes reader over a single-subscription socket stream.
class _SockReader {
  final StreamIterator<Uint8List> _it;
  Uint8List _buf = Uint8List(0);
  _SockReader(Stream<Uint8List> s) : _it = StreamIterator<Uint8List>(s);

  Future<Uint8List> read(int n) async {
    while (_buf.length < n) {
      if (!await _it.moveNext()) throw const SocketException('closed');
      _buf = concatBytes([_buf, _it.current]);
    }
    final out = Uint8List.fromList(_buf.sublist(0, n));
    _buf = Uint8List.fromList(_buf.sublist(n));
    return out;
  }

  Future<void> close() => _it.cancel();
}

class _Conn {
  final Socket socket;
  final _SockReader reader;
  _Conn(this.socket, this.reader);
}

/// Length-prefixed frames over TCP.
///
/// Tor mode: the embedded Tor daemon publishes a v3 onion service whose
/// HiddenServicePort forwards to [listenPort] on 127.0.0.1; outgoing
/// connections to *.onion go through the daemon's SOCKS5 port, with the
/// hostname resolved by Tor (no DNS leak).
///
/// [allowDirect] connects to plain host:port without Tor. It exists only for
/// development on a LAN and must stay off in release builds.
class TcpTransport implements Transport {
  static const int maxFrame = 64 * 1024;
  static const int _ack = 0x06;

  final int listenPort;
  final String socksHost;
  final int socksPort;
  final bool allowDirect;

  /// "host:port" other people use to reach us (our .onion, or LAN address).
  final String? advertise;

  ServerSocket? _server;
  final _in = StreamController<Uint8List>.broadcast();

  TcpTransport({
    this.listenPort = 7777,
    this.socksHost = '127.0.0.1',
    this.socksPort = 9050,
    this.allowDirect = false,
    this.advertise,
  });

  @override
  Stream<Uint8List> get incoming => _in.stream;

  @override
  PeerAddress get localAddress => PeerAddress(onion: advertise);

  /// Actual listening port (useful when [listenPort] is 0).
  int get boundPort => _server!.port;

  @override
  Future<void> start() async {
    _server = await ServerSocket.bind(
      allowDirect ? InternetAddress.anyIPv4 : InternetAddress.loopbackIPv4,
      listenPort,
    );
    _server!.listen(_serve, onError: (_) {});
  }

  Future<void> _serve(Socket s) async {
    final r = _SockReader(s);
    try {
      while (true) {
        final hdr = await r.read(4).timeout(const Duration(seconds: 30));
        final len = readU32be(hdr, 0);
        if (len == 0 || len > maxFrame) break;
        final body = await r.read(len).timeout(const Duration(seconds: 30));
        _in.add(body);
        s.add([_ack]);
        await s.flush();
      }
    } catch (_) {
      // closed / timeout / garbage: just drop the connection
    } finally {
      await r.close();
      s.destroy();
    }
  }

  static ({String host, int port}) _split(String hp) {
    final i = hp.lastIndexOf(':');
    if (i <= 0) throw FormatException('bad address $hp');
    return (host: hp.substring(0, i), port: int.parse(hp.substring(i + 1)));
  }

  Future<_Conn> _socks5(String host, int port) async {
    final s = await Socket.connect(socksHost, socksPort,
        timeout: const Duration(seconds: 15));
    final r = _SockReader(s);
    try {
      s.add([0x05, 0x01, 0x00]); // version 5, 1 method: no auth
      await s.flush();
      final m = await r.read(2).timeout(const Duration(seconds: 20));
      if (m[0] != 0x05 || m[1] != 0x00) throw const SocketException('socks auth');
      final hb = utf8.encode(host);
      s.add([0x05, 0x01, 0x00, 0x03, hb.length, ...hb, (port >> 8) & 0xFF, port & 0xFF]);
      await s.flush();
      // Reaching a hidden service can take a while (circuit building).
      final h = await r.read(4).timeout(const Duration(seconds: 90));
      if (h[1] != 0x00) throw SocketException('socks error ${h[1]}');
      switch (h[3]) {
        case 0x01:
          await r.read(4 + 2);
        case 0x03:
          final l = (await r.read(1))[0];
          await r.read(l + 2);
        case 0x04:
          await r.read(16 + 2);
        default:
          throw const SocketException('socks atyp');
      }
      return _Conn(s, r);
    } catch (_) {
      await r.close();
      s.destroy();
      rethrow;
    }
  }

  @override
  Future<bool> send(PeerAddress to, Uint8List frame) async {
    final target = to.onion;
    if (target == null || frame.length > maxFrame) return false;
    _Conn? c;
    try {
      final hp = _split(target);
      if (hp.host.endsWith('.onion')) {
        c = await _socks5(hp.host, hp.port);
      } else if (allowDirect) {
        final s = await Socket.connect(hp.host, hp.port,
            timeout: const Duration(seconds: 10));
        c = _Conn(s, _SockReader(s));
      } else {
        return false;
      }
      c.socket.add(concatBytes([u32be(frame.length), frame]));
      await c.socket.flush();
      final a = await c.reader.read(1).timeout(const Duration(seconds: 30));
      return a[0] == _ack;
    } catch (_) {
      return false;
    } finally {
      if (c != null) {
        await c.reader.close();
        c.socket.destroy();
      }
    }
  }

  @override
  Future<void> stop() async {
    await _server?.close();
    _server = null;
  }
}

/// First private IPv4 address of this device (dev mode only).
Future<String?> findLanAddress() async {
  for (final i in await NetworkInterface.list(type: InternetAddressType.IPv4)) {
    for (final a in i.addresses) {
      if (!a.isLoopback) return a.address;
    }
  }
  return null;
}
