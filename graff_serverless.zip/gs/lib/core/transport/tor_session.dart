import 'dart:async';

import '../storage/vault.dart';
import 'tcp_transport.dart';
import 'tor_control.dart';

/// Starts the platform's Tor daemon and returns the path of its control
/// socket. Android: see android_overlay/MainActivity.kt.
abstract class TorBackend {
  Future<String> start();
  Future<void> stop();
}

typedef TorConnector = Future<TorControl> Function(String controlSocketPath);

/// Brings Tor up and turns it into a [TcpTransport] reachable at a stable
/// onion address: bootstrap -> SOCKS endpoint -> onion service.
///
/// The onion private key is the device's long-term network identity. It is
/// stored only inside the encrypted [Vault] and handed to Tor over the local
/// control socket.
class TorSession {
  static const _vaultKey = 'tor/onion';

  final TcpTransport transport;
  final String onionAddress; // "<id>.onion"
  final TorControl _control;
  final TorBackend _backend;

  TorSession._(this.transport, this.onionAddress, this._control, this._backend);

  static Future<TorSession> start({
    required TorBackend backend,
    required Vault vault,
    int listenPort = 7777,
    int virtualPort = 80,
    Duration bootstrapTimeout = const Duration(minutes: 2),
    void Function(int percent)? onProgress,
    TorConnector? connector,
  }) async {
    final path = await backend.start();
    final ctl = await (connector ?? TorControl.connectUnix)(path);
    try {
      await ctl.authenticate();
      await ctl.waitBootstrapped(
          timeout: bootstrapTimeout, onProgress: onProgress);
      final socks = await ctl.socksEndpoint();

      final stored = await vault.getJson(_vaultKey) as Map<String, dynamic>?;
      final svc = await _publish(ctl, stored, virtualPort, listenPort);
      if (stored == null || stored['id'] != svc.serviceId) {
        await vault.putJson(
            _vaultKey, {'id': svc.serviceId, 'key': svc.privateKey});
      }

      final transport = TcpTransport(
        listenPort: listenPort,
        socksHost: socks.host,
        socksPort: socks.port,
        allowDirect: false, // never leak outside Tor
        advertise: '${svc.address}:$virtualPort',
      );
      return TorSession._(
          transport, '${svc.address}:$virtualPort', ctl, backend);
    } catch (_) {
      await ctl.close();
      rethrow;
    }
  }

  static Future<OnionService> _publish(TorControl ctl,
      Map<String, dynamic>? stored, int virtualPort, int listenPort) async {
    final key = stored?['key'] as String?;
    try {
      return await ctl.addOnion(
          privateKey: key, virtualPort: virtualPort, targetPort: listenPort);
    } on TorControlException catch (e) {
      // Tor outlived the app and still runs this service: replace it so the
      // port mapping is certainly ours (550 = onion address collision).
      if (e.code == 550 && stored != null) {
        await ctl.delOnion(stored['id'] as String);
        return ctl.addOnion(
            privateKey: key, virtualPort: virtualPort, targetPort: listenPort);
      }
      rethrow;
    }
  }

  Future<void> close() async {
    await transport.stop();
    await _control.close();
    await _backend.stop();
  }
}
