import 'dart:async';
import 'dart:typed_data';

class PeerAddress {
  final String? onion; // "host:port"
  final String? ble;
  const PeerAddress({this.onion, this.ble});
}

/// A transport only moves opaque, already end-to-end-encrypted frames.
/// It never sees keys or plaintext, so Tor, Bluetooth, LAN or anything else
/// can be plugged in without touching the cryptography.
abstract class Transport {
  Stream<Uint8List> get incoming;
  PeerAddress get localAddress;
  Future<void> start();

  /// true = the peer acknowledged the frame; false = unreachable (retry later).
  Future<bool> send(PeerAddress to, Uint8List frame);
  Future<void> stop();
}

/// Tries several transports in order (e.g. Bluetooth if the peer is nearby,
/// otherwise Tor) and merges their incoming streams.
class MultiTransport implements Transport {
  final List<Transport> children;
  final _in = StreamController<Uint8List>.broadcast();
  final _subs = <StreamSubscription<Uint8List>>[];

  MultiTransport(this.children);

  @override
  Stream<Uint8List> get incoming => _in.stream;

  @override
  PeerAddress get localAddress {
    String? onion, ble;
    for (final c in children) {
      onion ??= c.localAddress.onion;
      ble ??= c.localAddress.ble;
    }
    return PeerAddress(onion: onion, ble: ble);
  }

  @override
  Future<void> start() async {
    for (final c in children) {
      await c.start();
      _subs.add(c.incoming.listen(_in.add));
    }
  }

  @override
  Future<bool> send(PeerAddress to, Uint8List frame) async {
    for (final c in children) {
      try {
        if (await c.send(to, frame)) return true;
      } catch (_) {}
    }
    return false;
  }

  @override
  Future<void> stop() async {
    for (final s in _subs) {
      await s.cancel();
    }
    _subs.clear();
    for (final c in children) {
      await c.stop();
    }
  }
}

/// In-memory network for tests.
class LoopbackHub {
  final Map<String, LoopbackTransport> nodes = {};
}

class LoopbackTransport implements Transport {
  final LoopbackHub hub;
  final String address;
  bool online = true;
  final _in = StreamController<Uint8List>.broadcast();

  /// Every frame this node successfully sent (tests replay them).
  final List<Uint8List> sentLog = [];

  LoopbackTransport(this.hub, this.address);

  /// Delivers a frame as if it had arrived from the network.
  void inject(Uint8List frame) => _in.add(Uint8List.fromList(frame));

  @override
  Stream<Uint8List> get incoming => _in.stream;

  @override
  PeerAddress get localAddress => PeerAddress(onion: address);

  @override
  Future<void> start() async => hub.nodes[address] = this;

  @override
  Future<bool> send(PeerAddress to, Uint8List frame) async {
    final t = hub.nodes[to.onion];
    if (!online || t == null || !t.online) return false;
    sentLog.add(Uint8List.fromList(frame));
    t._in.add(Uint8List.fromList(frame));
    return true;
  }

  @override
  Future<void> stop() async => hub.nodes.remove(address);
}
