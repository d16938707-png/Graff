import 'dart:async';
import 'dart:convert';
import 'dart:io';

class TorControlException implements Exception {
  final int code;
  final String message;
  const TorControlException(this.code, this.message);
  @override
  String toString() => 'TorControlException($code): $message';
}

class TorReply {
  final int code;
  final List<String> lines;
  const TorReply(this.code, this.lines);
  bool get ok => code == 250;
}

class OnionService {
  final String serviceId; // 56 chars, without ".onion"
  final String privateKey; // "ED25519-V3:<base64>", secret!
  const OnionService(this.serviceId, this.privateKey);
  String get address => '$serviceId.onion';
}

final _serviceIdRe = RegExp(r'^[a-z2-7]{56}$');
final _privateKeyRe = RegExp(r'^ED25519-V3:[A-Za-z0-9+/=]+$');

/// Client for the Tor control protocol (control-spec). Works over a Unix
/// socket (Android TorService exposes one) or TCP (desktop tor, tests).
class TorControl {
  final Socket _socket;
  final StreamIterator<String> _lines;
  Future<void> _tail = Future<void>.value();

  TorControl._(this._socket, this._lines);

  static TorControl fromSocket(Socket s) {
    final lines = s
        .cast<List<int>>()
        .transform(utf8.decoder)
        .transform(const LineSplitter());
    return TorControl._(s, StreamIterator<String>(lines));
  }

  /// Retries until Tor has created the socket file or [timeout] passes.
  static Future<TorControl> connectUnix(
    String path, {
    Duration timeout = const Duration(seconds: 30),
  }) async {
    final deadline = DateTime.now().add(timeout);
    final addr = InternetAddress(path, type: InternetAddressType.unix);
    while (true) {
      try {
        return fromSocket(await Socket.connect(addr, 0));
      } on SocketException {
        if (DateTime.now().isAfter(deadline)) rethrow;
        await Future<void>.delayed(const Duration(milliseconds: 300));
      }
    }
  }

  static Future<TorControl> connectTcp(String host, int port) async =>
      fromSocket(await Socket.connect(host, port));

  /// Sends one command and returns the complete reply. Commands are
  /// serialized, so callers may fire them concurrently.
  Future<TorReply> send(String command) {
    if (command.contains('\r') || command.contains('\n')) {
      throw ArgumentError('control command must be a single line');
    }
    final c = Completer<TorReply>();
    final prev = _tail;
    _tail = c.future.then((_) {}, onError: (_) {});
    prev.then((_) async {
      try {
        _socket.write('$command\r\n');
        c.complete(await _readReply());
      } catch (e, s) {
        c.completeError(e, s);
      }
    });
    return c.future;
  }

  Future<String> _next() async {
    if (!await _lines.moveNext()) {
      throw const SocketException('control connection closed');
    }
    return _lines.current;
  }

  Future<TorReply> _readReply() async {
    final out = <String>[];
    while (true) {
      final line = await _next();
      if (line.length < 4) throw FormatException('bad control line: $line');
      final code = int.tryParse(line.substring(0, 3));
      if (code == null) throw FormatException('bad control line: $line');
      final sep = line[3];
      final body = line.substring(4);
      if (sep == '+') {
        final data = <String>[];
        while (true) {
          final l = await _next();
          if (l == '.') break;
          data.add(l.startsWith('..') ? l.substring(1) : l);
        }
        out.add('$body\n${data.join('\n')}');
      } else if (sep == '-' || sep == ' ') {
        out.add(body);
      } else {
        throw FormatException('bad control line: $line');
      }
      if (sep == ' ') return TorReply(code, out);
    }
  }

  Future<TorReply> _ok(String command) async {
    final r = await send(command);
    if (!r.ok) throw TorControlException(r.code, r.lines.join(' '));
    return r;
  }

  /// Android's TorService runs with CookieAuthentication 0 and no password,
  /// so a bare AUTHENTICATE is accepted on its private ControlSocket.
  Future<void> authenticate({String? password}) async {
    if (password == null) {
      await _ok('AUTHENTICATE');
    } else {
      final esc = password.replaceAll(r'\', r'\\').replaceAll('"', r'\"');
      await _ok('AUTHENTICATE "$esc"');
    }
  }

  Future<String?> getInfo(String key) async {
    final r = await _ok('GETINFO $key');
    final prefix = '$key=';
    for (final l in r.lines) {
      if (l.startsWith(prefix)) {
        return l.substring(prefix.length).replaceFirst(RegExp(r'^\n'), '');
      }
    }
    return null;
  }

  Future<void> waitBootstrapped({
    Duration timeout = const Duration(minutes: 2),
    Duration poll = const Duration(milliseconds: 500),
    void Function(int percent)? onProgress,
  }) async {
    final deadline = DateTime.now().add(timeout);
    while (true) {
      final info = await getInfo('status/bootstrap-phase');
      final m = RegExp(r'PROGRESS=(\d+)').firstMatch(info ?? '');
      final p = m == null ? 0 : int.parse(m.group(1)!);
      onProgress?.call(p);
      if (p >= 100) return;
      if (DateTime.now().isAfter(deadline)) {
        throw TimeoutException('Tor bootstrap stuck at $p%');
      }
      await Future<void>.delayed(poll);
    }
  }

  /// First IPv4 SOCKS listener of the running Tor.
  Future<({String host, int port})> socksEndpoint() async {
    final v = await getInfo('net/listeners/socks') ?? '';
    final m = RegExp(r'(\d+\.\d+\.\d+\.\d+):(\d+)').firstMatch(v);
    if (m == null) throw const TorControlException(0, 'no SOCKS listener');
    return (host: m.group(1)!, port: int.parse(m.group(2)!));
  }

  /// Publishes a v3 onion service forwarding virtualPort -> 127.0.0.1:target.
  /// Pass [privateKey] to get the same address again; null creates a new one.
  /// `Detach` keeps the service alive even if this connection closes.
  Future<OnionService> addOnion({
    String? privateKey,
    required int virtualPort,
    required int targetPort,
  }) async {
    if (privateKey != null && !_privateKeyRe.hasMatch(privateKey)) {
      throw ArgumentError('malformed onion private key');
    }
    final key = privateKey ?? 'NEW:ED25519-V3';
    final r = await _ok(
        'ADD_ONION $key Flags=Detach Port=$virtualPort,127.0.0.1:$targetPort');
    String? id;
    String? pk = privateKey;
    for (final l in r.lines) {
      if (l.startsWith('ServiceID=')) id = l.substring(10);
      if (l.startsWith('PrivateKey=')) pk = l.substring(11);
    }
    if (id == null || !_serviceIdRe.hasMatch(id)) {
      throw const TorControlException(0, 'bad ServiceID from tor');
    }
    if (pk == null || !_privateKeyRe.hasMatch(pk)) {
      throw const TorControlException(0, 'no private key from tor');
    }
    return OnionService(id, pk);
  }

  Future<void> delOnion(String serviceId) async {
    if (!_serviceIdRe.hasMatch(serviceId)) throw ArgumentError('bad id');
    await _ok('DEL_ONION $serviceId');
  }

  Future<void> close() async {
    await _lines.cancel();
    _socket.destroy();
  }
}
