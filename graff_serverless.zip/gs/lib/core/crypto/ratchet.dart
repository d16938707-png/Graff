import 'dart:typed_data';

import 'aead.dart';
import 'bytes.dart';
import 'dh.dart';
import 'kdf.dart';

class RatchetHeader {
  static const int size = 40; // dh(32) | pn(4) | n(4)
  final Uint8List dh;
  final int pn;
  final int n;
  const RatchetHeader(this.dh, this.pn, this.n);

  Uint8List toBytes() => concatBytes([dh, u32be(pn), u32be(n)]);

  static RatchetHeader parse(Uint8List b) {
    if (b.length < size + macLength) {
      throw const DecryptionFailure('message too short');
    }
    return RatchetHeader(
      Uint8List.fromList(b.sublist(0, 32)),
      readU32be(b, 32),
      readU32be(b, 36),
    );
  }
}

/// Double Ratchet (Signal spec): X25519 + HKDF-SHA256 + HMAC-SHA256 chains +
/// ChaCha20-Poly1305. decrypt() is atomic: a forged or corrupted message
/// never changes the session state.
class DoubleRatchet {
  static const int maxSkip = 1000;
  static const int maxStoredSkipped = 2000;

  final Uint8List ad;
  Uint8List _dhsSeed;
  Uint8List _dhsPub;
  Uint8List? _dhr;
  Uint8List _rk;
  Uint8List? _cks;
  Uint8List? _ckr;
  int _ns;
  int _nr;
  int _pn;
  final Map<String, Uint8List> _skipped;

  DoubleRatchet._(this.ad, this._dhsSeed, this._dhsPub, this._dhr, this._rk,
      this._cks, this._ckr, this._ns, this._nr, this._pn, this._skipped);

  /// Peer's current ratchet public key (null until first message received).
  Uint8List? get remoteRatchetKey => _dhr;
  bool get canSend => _cks != null;

  static Future<DoubleRatchet> initSender(
    Uint8List sk,
    Uint8List ad,
    Uint8List remoteRatchetPub,
  ) async {
    final seed = randomBytes(32);
    final pub = await x25519Pub(seed);
    final r = await _kdfRk(sk, await x25519Dh(seed, remoteRatchetPub));
    return DoubleRatchet._(
        ad, seed, pub, remoteRatchetPub, r.rk, r.ck, null, 0, 0, 0, {});
  }

  static DoubleRatchet initReceiver(
    Uint8List sk,
    Uint8List ad,
    Uint8List ownSeed,
    Uint8List ownPub,
  ) =>
      DoubleRatchet._(ad, ownSeed, ownPub, null, sk, null, null, 0, 0, 0, {});

  static Future<({Uint8List rk, Uint8List ck})> _kdfRk(
      Uint8List rk, Uint8List dhOut) async {
    final out = await hkdf(dhOut, salt: rk, info: 'Graff-DR-RK-v1', length: 64);
    return (
      rk: Uint8List.fromList(out.sublist(0, 32)),
      ck: Uint8List.fromList(out.sublist(32, 64)),
    );
  }

  static Future<({Uint8List mk, Uint8List ck})> _kdfCk(Uint8List ck) async {
    return (
      mk: await hmacSha256(ck, const [0x01]),
      ck: await hmacSha256(ck, const [0x02]),
    );
  }

  Future<Uint8List> _seal(Uint8List mk, Uint8List plain, Uint8List hb) async {
    final km = await hkdf(mk, info: 'Graff-DR-MK-v1', length: 44);
    return aeadSeal(chacha20, km.sublist(0, 32), km.sublist(32, 44), plain,
        concatBytes([ad, hb]));
  }

  Future<Uint8List> _open(Uint8List mk, Uint8List sealed, Uint8List hb) async {
    final km = await hkdf(mk, info: 'Graff-DR-MK-v1', length: 44);
    return aeadOpen(chacha20, km.sublist(0, 32), km.sublist(32, 44), sealed,
        concatBytes([ad, hb]));
  }

  /// Returns header(40) || ciphertext || tag(16).
  Future<Uint8List> encrypt(Uint8List plaintext) async {
    final cks = _cks;
    if (cks == null) throw StateError('no sending chain yet');
    final step = await _kdfCk(cks);
    _cks = step.ck;
    final hb = RatchetHeader(_dhsPub, _pn, _ns).toBytes();
    _ns++;
    return concatBytes([hb, await _seal(step.mk, plaintext, hb)]);
  }

  Future<Uint8List> decrypt(Uint8List message) async {
    final work = DoubleRatchet.fromJson(toJson());
    final plain = await work._decryptInPlace(message);
    _assign(work);
    return plain;
  }

  Future<Uint8List> _decryptInPlace(Uint8List msg) async {
    final header = RatchetHeader.parse(msg);
    final hb = Uint8List.fromList(msg.sublist(0, RatchetHeader.size));
    final sealed = Uint8List.fromList(msg.sublist(RatchetHeader.size));

    final stored = _skipped.remove(_skipKey(header.dh, header.n));
    if (stored != null) return _open(stored, sealed, hb);

    final dhr = _dhr;
    if (dhr == null || !constantTimeEquals(header.dh, dhr)) {
      await _skipUntil(header.pn);
      await _dhRatchet(header.dh);
    }
    await _skipUntil(header.n);
    final step = await _kdfCk(_ckr!);
    _ckr = step.ck;
    _nr++;
    return _open(step.mk, sealed, hb);
  }

  String _skipKey(Uint8List dh, int n) => '${toHex(dh)}:$n';

  Future<void> _skipUntil(int until) async {
    final ckr = _ckr;
    if (ckr == null) return;
    if (until - _nr > maxSkip) {
      throw const DecryptionFailure('too many skipped messages');
    }
    var ck = ckr;
    while (_nr < until) {
      final step = await _kdfCk(ck);
      ck = step.ck;
      _skipped[_skipKey(_dhr!, _nr)] = step.mk;
      _nr++;
    }
    _ckr = ck;
    while (_skipped.length > maxStoredSkipped) {
      _skipped.remove(_skipped.keys.first);
    }
  }

  Future<void> _dhRatchet(Uint8List remote) async {
    _pn = _ns;
    _ns = 0;
    _nr = 0;
    _dhr = remote;
    final r1 = await _kdfRk(_rk, await x25519Dh(_dhsSeed, remote));
    _rk = r1.rk;
    _ckr = r1.ck;
    _dhsSeed = randomBytes(32);
    _dhsPub = await x25519Pub(_dhsSeed);
    final r2 = await _kdfRk(_rk, await x25519Dh(_dhsSeed, remote));
    _rk = r2.rk;
    _cks = r2.ck;
  }

  void _assign(DoubleRatchet o) {
    _dhsSeed = o._dhsSeed;
    _dhsPub = o._dhsPub;
    _dhr = o._dhr;
    _rk = o._rk;
    _cks = o._cks;
    _ckr = o._ckr;
    _ns = o._ns;
    _nr = o._nr;
    _pn = o._pn;
    _skipped
      ..clear()
      ..addAll(o._skipped);
  }

  Map<String, dynamic> toJson() {
    final dhr = _dhr, cks = _cks, ckr = _ckr;
    return {
      'ad': b64u(ad),
      'dhsSeed': b64u(_dhsSeed),
      'dhsPub': b64u(_dhsPub),
      'dhr': dhr == null ? null : b64u(dhr),
      'rk': b64u(_rk),
      'cks': cks == null ? null : b64u(cks),
      'ckr': ckr == null ? null : b64u(ckr),
      'ns': _ns,
      'nr': _nr,
      'pn': _pn,
      'skipped': _skipped.map((k, v) => MapEntry(k, b64u(v))),
    };
  }

  factory DoubleRatchet.fromJson(Map<String, dynamic> j) {
    Uint8List? opt(String k) =>
        j[k] == null ? null : unb64u(j[k] as String);
    return DoubleRatchet._(
      unb64u(j['ad'] as String),
      unb64u(j['dhsSeed'] as String),
      unb64u(j['dhsPub'] as String),
      opt('dhr'),
      unb64u(j['rk'] as String),
      opt('cks'),
      opt('ckr'),
      j['ns'] as int,
      j['nr'] as int,
      j['pn'] as int,
      (j['skipped'] as Map<String, dynamic>)
          .map((k, v) => MapEntry(k, unb64u(v as String))),
    );
  }
}
