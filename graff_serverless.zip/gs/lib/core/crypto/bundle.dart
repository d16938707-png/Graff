import 'dart:convert';
import 'dart:typed_data';

import 'bytes.dart';
import 'dh.dart';
import 'identity.dart';

const String bundlePrefix = 'graff://c/';

/// Public contact card exchanged out-of-band (QR / link / NFC / in person).
/// There is no server that could hand out prekeys, so the card carries them.
class ContactBundle {
  final String name;
  final Uint8List edPub, xPub, spkPub, spkSig;

  /// "host:port" of the Tor onion service (or LAN address in dev mode).
  final String? onion;

  /// Bluetooth service/peer identifier for nearby delivery.
  final String? ble;

  ContactBundle({
    required this.name,
    required this.edPub,
    required this.xPub,
    required this.spkPub,
    required this.spkSig,
    this.onion,
    this.ble,
  });

  factory ContactBundle.fromIdentity(Identity id,
          {String? onion, String? ble}) =>
      ContactBundle(
        name: id.name,
        edPub: id.edPub,
        xPub: id.xPub,
        spkPub: id.spkPub,
        spkSig: id.spkSig,
        onion: onion,
        ble: ble,
      );

  Future<bool> verify() => ed25519Verify(
      edPub, bundleSignedData(xPub, spkPub), spkSig);

  Future<String> id() => identityId(edPub, xPub);

  Map<String, dynamic> toJson() => {
        'v': 1,
        'n': name,
        'ed': b64u(edPub),
        'x': b64u(xPub),
        'spk': b64u(spkPub),
        'sig': b64u(spkSig),
        if (onion != null) 'o': onion,
        if (ble != null) 'b': ble,
      };

  String toLink() => bundlePrefix + b64u(utf8.encode(jsonEncode(toJson())));

  static ContactBundle fromLink(String link) {
    final s = link.trim();
    if (!s.startsWith(bundlePrefix)) {
      throw const FormatException('not a graff contact link');
    }
    final j = jsonDecode(utf8.decode(unb64u(s.substring(bundlePrefix.length))))
        as Map<String, dynamic>;
    if (j['v'] != 1) throw const FormatException('unsupported version');
    final b = ContactBundle(
      name: (j['n'] as String).trim(),
      edPub: unb64u(j['ed'] as String),
      xPub: unb64u(j['x'] as String),
      spkPub: unb64u(j['spk'] as String),
      spkSig: unb64u(j['sig'] as String),
      onion: j['o'] as String?,
      ble: j['b'] as String?,
    );
    if (b.edPub.length != 32 ||
        b.xPub.length != 32 ||
        b.spkPub.length != 32 ||
        b.spkSig.length != 64) {
      throw const FormatException('bad key length');
    }
    return b;
  }
}
