import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

final _x25519 = X25519();
final _ed25519 = Ed25519();

Future<Uint8List> x25519Pub(Uint8List seed) async {
  final kp = await _x25519.newKeyPairFromSeed(seed);
  return Uint8List.fromList((await kp.extractPublicKey()).bytes);
}

Future<Uint8List> x25519Dh(Uint8List seed, Uint8List remotePub) async {
  final kp = await _x25519.newKeyPairFromSeed(seed);
  final shared = await _x25519.sharedSecretKey(
    keyPair: kp,
    remotePublicKey: SimplePublicKey(remotePub, type: KeyPairType.x25519),
  );
  return Uint8List.fromList(await shared.extractBytes());
}

Future<Uint8List> ed25519Pub(Uint8List seed) async {
  final kp = await _ed25519.newKeyPairFromSeed(seed);
  return Uint8List.fromList((await kp.extractPublicKey()).bytes);
}

Future<Uint8List> ed25519Sign(Uint8List seed, List<int> data) async {
  final kp = await _ed25519.newKeyPairFromSeed(seed);
  final sig = await _ed25519.sign(data, keyPair: kp);
  return Uint8List.fromList(sig.bytes);
}

Future<bool> ed25519Verify(
  Uint8List pub,
  List<int> data,
  Uint8List signature,
) async {
  try {
    return await _ed25519.verify(
      data,
      signature: Signature(
        signature,
        publicKey: SimplePublicKey(pub, type: KeyPairType.ed25519),
      ),
    );
  } catch (_) {
    return false;
  }
}
