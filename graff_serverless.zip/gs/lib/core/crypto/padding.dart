import 'dart:typed_data';

import 'bytes.dart';

const _buckets = [256, 512, 1024, 2048, 4096, 8192, 16384];

int _bucket(int n) {
  for (final b in _buckets) {
    if (n <= b) return b;
  }
  return ((n + 8191) ~/ 8192) * 8192;
}

/// 4-byte length || data || zeros, rounded up to a size bucket, so that the
/// ciphertext length does not reveal the message length.
Uint8List padPlain(Uint8List data) {
  final out = Uint8List(_bucket(data.length + 4));
  out.setRange(0, 4, u32be(data.length));
  out.setRange(4, 4 + data.length, data);
  return out;
}

Uint8List unpadPlain(Uint8List p) {
  if (p.length < 4) throw const FormatException('bad padding');
  final len = readU32be(p, 0);
  if (len + 4 > p.length) throw const FormatException('bad padding');
  return Uint8List.fromList(p.sublist(4, 4 + len));
}
