import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

class DecryptionFailure implements Exception {
  final String reason;
  const DecryptionFailure([this.reason = 'decryption failed']);
  @override
  String toString() => 'DecryptionFailure: $reason';
}

/// 12-byte nonce. Used by the ratchet (every message key is single-use).
final Cipher chacha20 = Chacha20.poly1305Aead();

/// 24-byte nonce. Used by the vault (random nonces are safe).
final Cipher xchacha20 = Xchacha20.poly1305Aead();

const int macLength = 16;

/// Returns ciphertext || 16-byte tag.
Future<Uint8List> aeadSeal(
  Cipher cipher,
  List<int> key,
  List<int> nonce,
  List<int> plaintext,
  List<int> aad,
) async {
  final box = await cipher.encrypt(
    plaintext,
    secretKey: SecretKey(key),
    nonce: nonce,
    aad: aad,
  );
  return Uint8List.fromList([...box.cipherText, ...box.mac.bytes]);
}

Future<Uint8List> aeadOpen(
  Cipher cipher,
  List<int> key,
  List<int> nonce,
  List<int> sealed,
  List<int> aad,
) async {
  if (sealed.length < macLength) {
    throw const DecryptionFailure('too short');
  }
  final ct = sealed.sublist(0, sealed.length - macLength);
  final mac = Mac(sealed.sublist(sealed.length - macLength));
  try {
    final clear = await cipher.decrypt(
      SecretBox(ct, nonce: nonce, mac: mac),
      secretKey: SecretKey(key),
      aad: aad,
    );
    return Uint8List.fromList(clear);
  } on SecretBoxAuthenticationError {
    throw const DecryptionFailure('authentication failed');
  }
}
