import 'dart:convert';
import 'dart:typed_data';

import 'bytes.dart';
import 'dh.dart';
import 'kdf.dart';

Uint8List bundleSignedData(Uint8List xPub, Uint8List spkPub) =>
    concatBytes([utf8.encode('graff-bundle-v1'), xPub, spkPub]);

/// Short public identifier (80 bits of SHA-256 over both identity keys).
/// Only a label: all security decisions use the full public keys.
Future<String> identityId(Uint8List edPub, Uint8List xPub) async {
  final h = await sha256(concatBytes([edPub, xPub]));
  return toHex(h.sublist(0, 10));
}

/// Long-term keys of this device. No phone number, no e-mail, no account.
class Identity {
  final String name;
  final Uint8List edSeed, edPub; // Ed25519: signs the bundle
  final Uint8List xSeed, xPub; // X25519 identity key (for the handshake)
  final Uint8List spkSeed, spkPub; // X25519 signed prekey
  final Uint8List spkSig;
  final String id;

  Identity._(this.name, this.edSeed, this.edPub, this.xSeed, this.xPub,
      this.spkSeed, this.spkPub, this.spkSig, this.id);

  static Future<Identity> generate(String name) =>
      _build(name, randomBytes(32), randomBytes(32), randomBytes(32));

  static Future<Identity> _build(
    String name,
    Uint8List edSeed,
    Uint8List xSeed,
    Uint8List spkSeed,
  ) async {
    final edPub = await ed25519Pub(edSeed);
    final xPub = await x25519Pub(xSeed);
    final spkPub = await x25519Pub(spkSeed);
    final sig = await ed25519Sign(edSeed, bundleSignedData(xPub, spkPub));
    final id = await identityId(edPub, xPub);
    return Identity._(name, edSeed, edPub, xSeed, xPub, spkSeed, spkPub, sig, id);
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'ed': b64u(edSeed),
        'x': b64u(xSeed),
        'spk': b64u(spkSeed),
      };

  static Future<Identity> fromJson(Map<String, dynamic> j) => _build(
        j['name'] as String,
        unb64u(j['ed'] as String),
        unb64u(j['x'] as String),
        unb64u(j['spk'] as String),
      );
}
