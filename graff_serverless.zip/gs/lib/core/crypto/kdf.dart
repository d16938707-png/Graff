import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

final _hmac = Hmac.sha256();

Future<Uint8List> hmacSha256(List<int> key, List<int> data) async {
  final mac = await _hmac.calculateMac(data, secretKey: SecretKey(key));
  return Uint8List.fromList(mac.bytes);
}

/// HKDF-SHA256. [salt] empty => zero-filled salt per RFC 5869.
Future<Uint8List> hkdf(
  List<int> ikm, {
  List<int> salt = const <int>[],
  required String info,
  required int length,
}) async {
  final h = Hkdf(hmac: Hmac.sha256(), outputLength: length);
  final k = await h.deriveKey(
    secretKey: SecretKey(ikm),
    nonce: salt,
    info: utf8.encode(info),
  );
  return Uint8List.fromList(await k.extractBytes());
}

Future<Uint8List> sha256(List<int> data) async =>
    Uint8List.fromList((await Sha256().hash(data)).bytes);
