import 'dart:typed_data';

import 'bytes.dart';
import 'bundle.dart';
import 'dh.dart';
import 'identity.dart';
import 'kdf.dart';

class HandshakeResult {
  final Uint8List sk; // shared secret -> root key of the ratchet
  final Uint8List ad; // associated data bound into every message
  final Uint8List? ekPub; // ephemeral public key (initiator only)
  HandshakeResult(this.sk, this.ad, this.ekPub);
}

Future<Uint8List> _derive(List<Uint8List> dhs) {
  final f = Uint8List(32)..fillRange(0, 32, 0xFF);
  return hkdf(concatBytes([f, ...dhs]), info: 'Graff-X3DH-v1', length: 32);
}

/// X3DH without one-time prekeys (the bundle is static and offline).
/// Initiator side. [them] must already be signature-verified.
Future<HandshakeResult> x3dhInitiate({
  required Identity me,
  required ContactBundle them,
}) async {
  final ekSeed = randomBytes(32);
  final ekPub = await x25519Pub(ekSeed);
  final dh1 = await x25519Dh(me.xSeed, them.spkPub);
  final dh2 = await x25519Dh(ekSeed, them.xPub);
  final dh3 = await x25519Dh(ekSeed, them.spkPub);
  final sk = await _derive([dh1, dh2, dh3]);
  final ad = concatBytes([me.xPub, me.edPub, them.xPub, them.edPub]);
  return HandshakeResult(sk, ad, ekPub);
}

Future<HandshakeResult> x3dhRespond({
  required Identity me,
  required ContactBundle initiator,
  required Uint8List ekPub,
}) async {
  final dh1 = await x25519Dh(me.spkSeed, initiator.xPub);
  final dh2 = await x25519Dh(me.xSeed, ekPub);
  final dh3 = await x25519Dh(me.spkSeed, ekPub);
  final sk = await _derive([dh1, dh2, dh3]);
  final ad = concatBytes([initiator.xPub, initiator.edPub, me.xPub, me.edPub]);
  return HandshakeResult(sk, ad, null);
}
