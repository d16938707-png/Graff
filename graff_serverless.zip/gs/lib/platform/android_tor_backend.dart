import 'package:flutter/services.dart';

import '../core/transport/tor_session.dart';

/// Talks to android_overlay/MainActivity.kt, which binds Guardian Project's
/// TorService (libtor.so in-process) and reports where its private control
/// socket lives. Everything else (bootstrap wait, onion service, SOCKS port)
/// is done in Dart by TorSession.
class AndroidTorBackend implements TorBackend {
  static const _channel = MethodChannel('graff/tor');

  @override
  Future<String> start() async {
    final path = await _channel.invokeMethod<String>('start');
    if (path == null) throw StateError('Tor backend returned no socket path');
    return path;
  }

  @override
  Future<void> stop() => _channel.invokeMethod<void>('stop');
}
