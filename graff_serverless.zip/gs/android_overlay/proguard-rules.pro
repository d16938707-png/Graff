# TorService is called from native code (JNI) and via reflection-like binding.
-keep class org.torproject.jni.** { *; }
-keep class net.freehaven.tor.control.** { *; }
