# Android: подключение Tor

**Быстро:** после `flutter create --org app.graff --project-name graff .`
выполните `python3 tool/prepare_android.py` — он делает шаги 2–5 ниже сам
(проверен на макетах Kotlin DSL и Groovy; при непонятной структуре файлов
останавливается с ошибкой, а не собирает без Tor). Ниже то же вручную.

Проверено только Dart-часть (тесты на фейковом Tor). Нативная часть не
собиралась: возможны мелкие правки под вашу версию Flutter/AGP.

## 1. Создать платформенные папки

    flutter create --org app.graff --project-name graff .

Пакет приложения станет `app.graff.graff` (как в MainActivity.kt).

## 2. Скопировать файлы

    cp android_overlay/MainActivity.kt \
       android/app/src/main/kotlin/app/graff/graff/MainActivity.kt
    cp android_overlay/proguard-rules.pro android/app/proguard-rules.pro

## 3. Репозиторий Guardian Project

`android/build.gradle.kts` (новые шаблоны Flutter):

    allprojects {
        repositories {
            google()
            mavenCentral()
            maven { url = uri("https://raw.githubusercontent.com/guardianproject/gpmaven/master") }
        }
    }

Если у вас Groovy (`android/build.gradle`):

    allprojects {
        repositories {
            google()
            mavenCentral()
            maven { url "https://raw.githubusercontent.com/guardianproject/gpmaven/master" }
        }
    }

## 4. Зависимости, minSdk, R8

`android/app/build.gradle.kts`:

    android {
        defaultConfig { minSdk = 24 }          // требование tor-android
        buildTypes {
            release {
                isMinifyEnabled = true
                proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"),
                              "proguard-rules.pro")
            }
        }
    }
    dependencies {
        implementation("info.guardianproject:tor-android:0.4.8.16")
        implementation("info.guardianproject:jtorctl:0.4.5.7")
    }

`tor-android` берётся из репозитория Guardian Project, а `jtorctl` — из
Maven Central (в репозитории Guardian Project его нет; `mavenCentral()` в
шаблоне Flutter уже подключён).

Версия 0.4.9.14 — security-релиз tor от 8 октября 2026 (см. CHANGELOG
репозитория guardianproject/tor-android); берите самую свежую.
**Версия Tor.** По умолчанию `tool/prepare_android.py` ставит
tor-android **0.4.8.16**: она собирается со стандартным compileSdk Flutter и
использует тот же ControlSocket, что нужен мосту. Но это не самый свежий Tor.
Версии 0.4.9.x (например 0.4.9.14, security-релиз tor от 8 октября 2026)
свежее, однако их метаданные требуют compileSdk 37.1 — эта сборка у меня не
проверялась. Когда базовая сборка заработает, попробуйте обновиться:

    GRAFF_TOR_VERSION=0.4.9.14 python3 tool/prepare_android.py

(скрипт сам поставит `compileSdk = 37` и `android.suppressUnsupportedCompileSdk=37`;
если Gradle попросит другой номер платформы, подставьте то, что он назовёт).
Для настоящего использования стоит перейти на актуальный Tor.

## 5. Манифест

`android/app/src/main/AndroidManifest.xml`:

    <uses-permission android:name="android.permission.INTERNET"/>
    <application
        android:allowBackup="false"
        android:fullBackupContent="false"
        ... >

`allowBackup=false` важен: иначе облачный/adb-бэкап унесёт зашифрованное
хранилище с устройства. Сервис TorService объявлен в манифесте самой
библиотеки, добавлять его не нужно.

## 6. Запуск

    flutter run --release                              # Tor включён сам
    flutter run --dart-define=GRAFF_TOR=true           # Tor в debug
    flutter run                                        # debug: LAN без Tor

Первое подключение к Tor занимает от нескольких секунд до минуты
(экран показывает проценты). Проверять на реальном устройстве arm64:
в эмуляторе x86 tor-android по умолчанию не собирается.

## Ограничение: Android убивает фоновые приложения

Пока приложение не на экране, система может остановить процесс, и вместе с ним
Tor: сообщения не доходят. Чтобы быть доступным постоянно, нужен foreground
service с уведомлением и запросом исключения из оптимизации батареи. Это
следующий этап и в этой версии не сделано.
