package app.graff.graff

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.torproject.jni.TorService
import java.io.File

/**
 * Starts Tor (Guardian Project tor-android, libtor.so inside this process)
 * and tells Dart where TorService's control socket is. Dart does the rest.
 */
class MainActivity : FlutterActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        // No screenshots, no thumbnails of private chats in the recents list.
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        super.onCreate(savedInstanceState)
    }

    // Same location TorService uses: getDir("TorService") + "/data/ControlSocket".
    private fun controlSocketPath(): String =
        File(File(getDir("TorService", Context.MODE_PRIVATE), "data"), "ControlSocket")
            .absolutePath

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "graff/tor")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "start" -> {
                        startTor()
                        // The socket file appears a moment later; Dart retries.
                        result.success(controlSocketPath())
                    }
                    "stop" -> {
                        stopTor()
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun startTor() {
        if (connection != null) return
        val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {}
            override fun onServiceDisconnected(name: ComponentName?) {}
        }
        // Bound through the application context so that rotating the screen
        // (recreating the Activity) does not stop Tor.
        applicationContext.bindService(
            Intent(applicationContext, TorService::class.java),
            conn,
            Context.BIND_AUTO_CREATE
        )
        connection = conn
    }

    private fun stopTor() {
        connection?.let { applicationContext.unbindService(it) }
        connection = null
    }

    companion object {
        // Survives Activity recreation; one binding per process.
        private var connection: ServiceConnection? = null
    }
}
