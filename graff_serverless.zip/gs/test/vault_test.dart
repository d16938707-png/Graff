import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:graff/core/storage/blob_store.dart';
import 'package:graff/core/storage/vault.dart';

void main() {
  const fast = Argon2Params.fastForTests;

  test('create, reopen, wrong passphrase', () async {
    final store = MemoryBlobStore();
    final v = await Vault.create(store, 'correct horse', params: fast);
    await v.putJson('chat/abc', {'t': 'secret message'});

    final v2 = await Vault.unlock(store, 'correct horse');
    expect((await v2.getJson('chat/abc'))['t'], 'secret message');
    expect(v2.names('chat/'), ['chat/abc']);

    expect(() => Vault.unlock(store, 'wrong'), throwsA(isA<WrongPassphrase>()));
  });

  test('nothing readable on disk', () async {
    final store = MemoryBlobStore();
    final v = await Vault.create(store, 'pass-pass', params: fast);
    await v.putJson('chat/alice', {'t': 'TOPSECRETTEXT'});
    for (final e in store.blobs.entries) {
      expect(e.key.contains('alice'), isFalse);
      expect(String.fromCharCodes(e.value).contains('TOPSECRETTEXT'), isFalse);
    }
  });

  test('wipe destroys data', () async {
    final store = MemoryBlobStore();
    final v = await Vault.create(store, 'pass-pass', params: fast);
    await v.putBytes('k', Uint8List.fromList([1, 2, 3]));
    await v.wipe();
    expect(store.blobs, isEmpty);
    expect(await Vault.exists(store), isFalse);
  });
}
