import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:graff/core/graff_core.dart';
import 'package:graff/core/models.dart';
import 'package:graff/core/storage/blob_store.dart';
import 'package:graff/core/storage/vault.dart';
import 'package:graff/core/transport/transport.dart';

Future<(GraffCore, LoopbackTransport)> node(
    LoopbackHub hub, String name, String addr) async {
  final vault = await Vault.create(MemoryBlobStore(), 'pass-pass',
      params: Argon2Params.fastForTests);
  final t = LoopbackTransport(hub, addr);
  final core = await GraffCore.open(
    vault: vault,
    transport: t,
    newIdentityName: name,
    flushEvery: const Duration(hours: 1),
  );
  return (core, t);
}

Future<StoredMessage> next(GraffCore c) => c.events
    .map((e) => e.message)
    .first
    .timeout(const Duration(seconds: 10));

void main() {
  moreTests();
  test('two devices, no server: first message, reply, offline retry', () async {
    final hub = LoopbackHub();
    final (alice, _) = await node(hub, 'Alice', 'alice');
    final (bob, bobT) = await node(hub, 'Bob', 'bob');

    final aliceContact = await bob.addContact(alice.myLink());
    final bobContact = await alice.addContact(bob.myLink());

    // Alice -> Bob (handshake rides on the first message)
    var got = next(bob);
    await alice.sendText(bobContact.id, 'привет');
    expect((await got).text, 'привет');

    // Bob -> Alice
    got = next(alice);
    await bob.sendText(aliceContact.id, 'здравствуй');
    expect((await got).text, 'здравствуй');

    // Bob goes offline; Alice's message waits in the outbox
    bobT.online = false;
    await alice.sendText(bobContact.id, 'ты тут?');
    await alice.flushOutbox();
    expect((await alice.history(bobContact.id)).last.status, 'queued');

    // Bob is back; retry delivers it
    bobT.online = true;
    got = next(bob);
    await alice.flushOutbox();
    expect((await got).text, 'ты тут?');
    await Future<void>.delayed(const Duration(milliseconds: 50));
    expect((await alice.history(bobContact.id)).last.status, 'sent');
  });

  test('messages from strangers are dropped', () async {
    final hub = LoopbackHub();
    final (alice, _) = await node(hub, 'Alice', 'alice');
    final (bob, _) = await node(hub, 'Bob', 'bob');
    final (eve, _) = await node(hub, 'Eve', 'eve');

    // Eve knows Bob, Bob does not know Eve
    final bobForEve = await eve.addContact(bob.myLink());
    await bob.addContact(alice.myLink());

    var received = false;
    bob.events.listen((_) => received = true);
    await eve.sendText(bobForEve.id, 'spam');
    await Future<void>.delayed(const Duration(milliseconds: 300));
    expect(received, isFalse);
  });

  test('safety numbers match on both sides', () async {
    final hub = LoopbackHub();
    final (alice, _) = await node(hub, 'Alice', 'alice');
    final (bob, _) = await node(hub, 'Bob', 'bob');
    final b = await alice.addContact(bob.myLink());
    final a = await bob.addContact(alice.myLink());
    expect(await alice.safetyNumber(b.id), await bob.safetyNumber(a.id));
  });
}

void moreTests() {
  test('several messages before any reply all arrive, in any order', () async {
    final hub = LoopbackHub();
    final (alice, _) = await node(hub, 'Alice', 'alice');
    final (bob, bobT) = await node(hub, 'Bob', 'bob');
    final cb = await alice.addContact(bob.myLink());
    await bob.addContact(alice.myLink());

    bobT.online = false; // queue three first-flight messages
    await alice.sendText(cb.id, 'one');
    await alice.sendText(cb.id, 'two');
    await alice.sendText(cb.id, 'three');
    bobT.online = true;

    final texts = <String>[];
    final done = Completer<void>();
    bob.events.listen((e) {
      texts.add(e.message.text);
      if (texts.length == 3) done.complete();
    });
    await alice.flushOutbox();
    await done.future.timeout(const Duration(seconds: 10));
    expect(texts, ['one', 'two', 'three']);
    expect((await bob.history((await bob.contacts.first).id)).length, 3);
  });

  for (final aliceWins in [true, false]) {
    test('both write first at once, ${aliceWins ? 'Alice' : 'Bob'} wins the '
        'tie-break: nothing is lost', () async {
      final hub = LoopbackHub();
      // identities are random: draw until the wanted side has the smaller id
      late GraffCore alice, bob;
      late LoopbackTransport aT, bT;
      while (true) {
        final a = await node(hub, 'Alice', 'alice');
        final b = await node(hub, 'Bob', 'bob');
        if ((a.$1.identity.id.compareTo(b.$1.identity.id) < 0) == aliceWins) {
          alice = a.$1;
          aT = a.$2;
          bob = b.$1;
          bT = b.$2;
          break;
        }
        await a.$1.close();
        await b.$1.close();
      }
      final cb = await alice.addContact(bob.myLink());
      final ca = await bob.addContact(alice.myLink());

      aT.online = false;
      bT.online = false;
      await alice.sendText(cb.id, 'A-first');
      await bob.sendText(ca.id, 'B-first');
      aT.online = true;
      bT.online = true;
      await Future.wait([alice.flushOutbox(), bob.flushOutbox()]);
      for (var i = 0; i < 3; i++) {
        await Future<void>.delayed(const Duration(milliseconds: 100));
        await Future.wait([alice.flushOutbox(), bob.flushOutbox()]);
      }

      List<String> texts(List<StoredMessage> l, bool out) =>
          l.where((m) => m.outgoing == out).map((m) => m.text).toList();
      expect(texts(await bob.history(ca.id), false), ['A-first']);
      expect(texts(await alice.history(cb.id), false), ['B-first']);
      expect((await alice.history(cb.id)).first.status, 'sent');
      expect((await bob.history(ca.id)).first.status, 'sent');

      var got = next(bob);
      await alice.sendText(cb.id, 'A-second');
      expect((await got).text, 'A-second');
      got = next(alice);
      await bob.sendText(ca.id, 'B-second');
      expect((await got).text, 'B-second');
    });
  }

  test('a replayed/delayed old handshake cannot reset a session', () async {
    final hub = LoopbackHub();
    final (alice, aT) = await node(hub, 'Alice', 'alice');
    final (bob, bT) = await node(hub, 'Bob', 'bob');
    final cb = await alice.addContact(bob.myLink());
    final ca = await bob.addContact(alice.myLink());

    var got = next(bob);
    await alice.sendText(cb.id, 'hello');
    await got;
    got = next(alice);
    await bob.sendText(ca.id, 'hi');
    await got;

    final oldInit = aT.sentLog.first; // Alice's very first frame (an INIT)
    expect(oldInit[0], 0x01);
    bT.inject(oldInit);
    bT.inject(oldInit);
    await Future<void>.delayed(const Duration(milliseconds: 200));

    // no duplicate, session intact, both directions still work
    expect((await bob.history(ca.id)).where((m) => !m.outgoing).length, 1);
    got = next(bob);
    await alice.sendText(cb.id, 'still works');
    expect((await got).text, 'still works');
    got = next(alice);
    await bob.sendText(ca.id, 'me too');
    expect((await got).text, 'me too');
  });
}
