import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:graff/core/graff_core.dart';
import 'package:graff/core/storage/blob_store.dart';
import 'package:graff/core/storage/vault.dart';
import 'package:graff/core/transport/tcp_transport.dart';
import 'package:graff/core/transport/transport.dart';

import 'fakes.dart';

Uint8List bytes(List<int> l) => Uint8List.fromList(l);

void main() {
  test('Tor-style path: frames go through SOCKS5, hostname not resolved locally',
      () async {
    final socks = FakeSocks({});
    await socks.start();
    final a = TcpTransport(
        listenPort: 0,
        socksPort: 0, // patched below
        advertise: 'aaaa.onion:80');
    // ports are only known after binding, so create transports in two steps
    await a.start();
    final b0 = TcpTransport(listenPort: 0, advertise: 'bbbb.onion:80');
    await b0.start();
    socks.routes['aaaa.onion'] = a.boundPort;
    socks.routes['bbbb.onion'] = b0.boundPort;
    await a.stop();
    await b0.stop();

    final tA = TcpTransport(
        listenPort: socks.routes['aaaa.onion']!,
        socksPort: socks.server.port,
        advertise: 'aaaa.onion:80');
    final tB = TcpTransport(
        listenPort: socks.routes['bbbb.onion']!,
        socksPort: socks.server.port,
        advertise: 'bbbb.onion:80');
    await tA.start();
    await tB.start();

    final got = tB.incoming.first.timeout(const Duration(seconds: 5));
    final ok = await tA.send(
        const PeerAddress(onion: 'bbbb.onion:80'), bytes([1, 2, 3, 4, 5]));
    expect(ok, true);
    expect(await got, [1, 2, 3, 4, 5]);
    expect(socks.requestedHosts, ['bbbb.onion']);

    // unknown onion => proxy says unreachable => false (message stays queued)
    expect(
        await tA.send(const PeerAddress(onion: 'cccc.onion:80'), bytes([9])),
        false);
    // plain host without Tor and allowDirect=false must never connect
    expect(await tA.send(const PeerAddress(onion: '127.0.0.1:1'), bytes([9])),
        false);
    await tA.stop();
    await tB.stop();
  });

  test('full messenger over the SOCKS5/onion path with persistence', () async {
    final socks = FakeSocks({});
    await socks.start();

    // reserve two free ports
    final s1 = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    final s2 = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    final pa = s1.port, pb = s2.port;
    await s1.close();
    await s2.close();
    socks.routes['alice.onion'] = pa;
    socks.routes['bob.onion'] = pb;

    TcpTransport mk(int port, String onion) => TcpTransport(
        listenPort: port, socksPort: socks.server.port, advertise: '$onion:80');

    final dirA = await Directory.systemTemp.createTemp('graffA');
    final dirB = await Directory.systemTemp.createTemp('graffB');
    try {
      final va = await Vault.create(FileBlobStore(dirA), 'pass-alice',
          params: Argon2Params.fastForTests);
      final vb = await Vault.create(FileBlobStore(dirB), 'pass-bob',
          params: Argon2Params.fastForTests);
      var alice = await GraffCore.open(
          vault: va,
          transport: mk(pa, 'alice.onion'),
          newIdentityName: 'Alice',
          flushEvery: const Duration(hours: 1));
      var bob = await GraffCore.open(
          vault: vb,
          transport: mk(pb, 'bob.onion'),
          newIdentityName: 'Bob',
          flushEvery: const Duration(hours: 1));
      final cb = await alice.addContact(bob.myLink());
      final ca = await bob.addContact(alice.myLink());

      var got = bob.events.first.timeout(const Duration(seconds: 10));
      await alice.sendText(cb.id, 'привет по Tor');
      expect((await got).message.text, 'привет по Tor');

      // both restart from disk: sessions, contacts and history must survive
      await alice.close();
      await bob.close();
      alice = await GraffCore.open(
          vault: await Vault.unlock(FileBlobStore(dirA), 'pass-alice'),
          transport: mk(pa, 'alice.onion'),
          flushEvery: const Duration(hours: 1));
      bob = await GraffCore.open(
          vault: await Vault.unlock(FileBlobStore(dirB), 'pass-bob'),
          transport: mk(pb, 'bob.onion'),
          flushEvery: const Duration(hours: 1));
      expect(alice.contacts.length, 1);
      expect((await bob.history(ca.id)).map((m) => m.text).toList(), ['привет по Tor']);

      got = alice.events.first.timeout(const Duration(seconds: 10));
      await bob.sendText(ca.id, 'ответ после перезапуска');
      expect((await got).message.text, 'ответ после перезапуска');

      await alice.close();
      await bob.close();
    } finally {
      await dirA.delete(recursive: true);
      await dirB.delete(recursive: true);
    }
  });
}
