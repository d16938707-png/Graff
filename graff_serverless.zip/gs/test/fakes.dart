import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:graff/core/transport/tor_session.dart';

/// Minimal SOCKS5 proxy standing in for Tor: maps "<name>.onion" to a local
/// port and refuses unknown names with "host unreachable".
class FakeSocks {
  final Map<String, int> routes;
  late ServerSocket server;
  final List<String> requestedHosts = [];
  FakeSocks(this.routes);

  Future<void> start() async {
    server = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    server.listen(_handle);
  }

  void _handle(Socket c) {
    var state = 0;
    final buf = <int>[];
    Socket? up;
    c.listen((chunk) async {
      if (state == 2) {
        up?.add(chunk);
        return;
      }
      buf.addAll(chunk);
      if (state == 0 && buf.length >= 3) {
        buf.removeRange(0, 3);
        c.add([5, 0]);
        state = 1;
      }
      if (state == 1 && buf.length >= 5) {
        final hl = buf[4];
        if (buf.length >= 5 + hl + 2) {
          final host = String.fromCharCodes(buf.sublist(5, 5 + hl));
          buf.removeRange(0, 5 + hl + 2);
          requestedHosts.add(host);
          final port = routes[host];
          if (port == null) {
            c.add([5, 4, 0, 1, 0, 0, 0, 0, 0, 0]);
            await c.close();
            return;
          }
          state = 3; // connecting
          up = await Socket.connect('127.0.0.1', port);
          up!.listen(c.add, onDone: c.destroy, onError: (_) => c.destroy());
          c.add([5, 0, 0, 1, 0, 0, 0, 0, 0, 0]);
          if (buf.isNotEmpty) up!.add(buf);
          state = 2;
        }
      }
    }, onDone: () => up?.destroy(), onError: (_) => up?.destroy());
  }
}


/// Speaks enough of the Tor control protocol (over a real socket) to test
/// TorControl / TorSession: auth, bootstrap progress, SOCKS listener,
/// ADD_ONION / DEL_ONION incl. collisions, and multi-line replies.
class FakeTor {
  final String idChar;
  final int socksPort;
  final List<int> bootstrapSteps;
  final Map<String, int> services = {}; // service id -> target port
  final List<String> received = [];
  late ServerSocket server;
  int _bootCalls = 0;

  FakeTor(this.idChar,
      {this.socksPort = 9050, this.bootstrapSteps = const [0, 40, 100]});

  String get serviceId => idChar * 56;
  String get privateKey =>
      'ED25519-V3:${base64.encode(utf8.encode('fake-key-$idChar'))}';

  Future<void> startUnix(String path) async {
    server = await ServerSocket.bind(
        InternetAddress(path, type: InternetAddressType.unix), 0);
    server.listen(_handle);
  }

  Future<void> startTcp() async {
    server = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    server.listen(_handle);
  }

  Future<void> stop() => server.close();

  void _handle(Socket c) {
    var authed = false;
    c
        .cast<List<int>>()
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen((line) {
      received.add(line);
      final String out;
      if (line == 'AUTHENTICATE' || line.startsWith('AUTHENTICATE ')) {
        authed = true;
        out = '250 OK';
      } else if (!authed) {
        out = '514 Authentication required.';
      } else {
        out = _respond(line);
      }
      c.write('$out\r\n');
    }, onDone: c.destroy, onError: (_) => c.destroy());
  }

  String _respond(String line) {
    if (line == 'GETINFO status/bootstrap-phase') {
      final i = _bootCalls < bootstrapSteps.length
          ? _bootCalls
          : bootstrapSteps.length - 1;
      _bootCalls++;
      return '250-status/bootstrap-phase=NOTICE BOOTSTRAP PROGRESS=${bootstrapSteps[i]} TAG=x SUMMARY="y"\r\n250 OK';
    }
    if (line == 'GETINFO net/listeners/socks') {
      return '250-net/listeners/socks="127.0.0.1:$socksPort" "[::1]:$socksPort"\r\n250 OK';
    }
    if (line == 'GETINFO config-text') {
      return '250+config-text=\r\nSocksPort 9050\r\n..leading dot\r\nLast\r\n.\r\n250 OK';
    }
    if (line.startsWith('ADD_ONION ')) {
      final parts = line.split(' ');
      final key = parts[1];
      final isNew = key == 'NEW:ED25519-V3';
      if (!isNew && key != privateKey) return '513 Invalid key';
      final m = RegExp(r'Port=(\d+),127\.0\.0\.1:(\d+)').firstMatch(line);
      if (m == null) return '512 Bad port';
      if (!line.contains('Flags=Detach')) return '512 Bad flags';
      if (services.containsKey(serviceId)) {
        return '550 Onion address collision';
      }
      services[serviceId] = int.parse(m.group(2)!);
      return '250-ServiceID=$serviceId\r\n'
          '${isNew ? '250-PrivateKey=$privateKey\r\n' : ''}250 OK';
    }
    if (line.startsWith('DEL_ONION ')) {
      final id = line.substring(10);
      return services.remove(id) == null
          ? '552 Unknown Onion Service id'
          : '250 OK';
    }
    return '510 Unrecognized command';
  }
}

/// Backend that "starts Tor" by pointing at an already running FakeTor.
class FakeBackend implements TorBackend {
  final String path;
  int starts = 0, stops = 0;
  FakeBackend(this.path);
  @override
  Future<String> start() async {
    starts++;
    return path;
  }

  @override
  Future<void> stop() async => stops++;
}
