import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:graff/core/graff_core.dart';
import 'package:graff/core/storage/blob_store.dart';
import 'package:graff/core/storage/vault.dart';
import 'package:graff/core/transport/tor_control.dart';
import 'package:graff/core/transport/tor_session.dart';

import 'fakes.dart';

Future<Directory> tmp() => Directory.systemTemp.createTemp('graff_tor');

void main() {
  test('control protocol over a real unix socket', () async {
    final dir = await tmp();
    final tor = FakeTor('a', socksPort: 9150);
    await tor.startUnix('${dir.path}/ctl.sock');
    final ctl = await TorControl.connectUnix('${dir.path}/ctl.sock');
    try {
      // commands before AUTHENTICATE are refused by tor
      try {
        await ctl.getInfo('net/listeners/socks');
        expect('should have thrown', 'x');
      } on TorControlException catch (e) {
        expect(e.code, 514);
      }
      await ctl.authenticate();

      final progress = <int>[];
      await ctl.waitBootstrapped(
          poll: const Duration(milliseconds: 5), onProgress: progress.add);
      expect(progress, [0, 40, 100]);

      final socks = await ctl.socksEndpoint();
      expect(socks.host, '127.0.0.1');
      expect(socks.port, 9150);

      // multi-line (250+) reply with dot-stuffing
      expect(await ctl.getInfo('config-text'),
          'SocksPort 9050\n.leading dot\nLast');

      try {
        await ctl.send('BOGUS').then((r) {
          expect(r.code, 510);
        });
      } finally {}
    } finally {
      await ctl.close();
      await tor.stop();
      await dir.delete(recursive: true);
    }
  });

  test('control protocol over TCP, concurrent commands stay in order', () async {
    final tor = FakeTor('b');
    await tor.startTcp();
    final ctl = await TorControl.connectTcp('127.0.0.1', tor.server.port);
    await ctl.authenticate(password: 'pw "with" quotes');
    final results = await Future.wait([
      ctl.getInfo('net/listeners/socks'),
      ctl.getInfo('config-text'),
      ctl.getInfo('status/bootstrap-phase'),
    ]);
    expect(results[0]!.contains('127.0.0.1:9050'), true);
    expect(results[1]!.startsWith('SocksPort'), true);
    expect(results[2]!.contains('PROGRESS=0'), true);
    expect(tor.received.first, r'AUTHENTICATE "pw \"with\" quotes"');
    await ctl.close();
    await tor.stop();
  });

  test('onion address stays the same across app and Tor restarts', () async {
    final dir = await tmp();
    final path = '${dir.path}/ctl.sock';
    final store = MemoryBlobStore();
    var vault = await Vault.create(store, 'pass-pass',
        params: Argon2Params.fastForTests);
    var tor = FakeTor('c');
    await tor.startUnix(path);
    final backend = FakeBackend(path);
    Future<TorSession> run() => TorSession.start(
        backend: backend, vault: vault, listenPort: 17777);

    // first run: a NEW service is created, key goes into the vault
    final s1 = await run();
    final addr = s1.onionAddress;
    expect(addr, '${'c' * 56}.onion:80');
    expect(tor.services[tor.serviceId], 17777);
    final stored = await vault.getJson('tor/onion');
    expect(stored['key'], tor.privateKey);
    await s1.close();

    // app restarted, Tor still running with the service: collision handled
    vault = await Vault.unlock(store, 'pass-pass');
    final s2 = await run();
    expect(s2.onionAddress, addr);
    expect(tor.received.any((l) => l.startsWith('DEL_ONION ')), true);
    await s2.close();

    // Tor itself restarted (service gone): same key -> same address
    await tor.stop();
    tor = FakeTor('c');
    await tor.startUnix(path);
    final s3 = await run();
    expect(s3.onionAddress, addr);
    expect(tor.received.any((l) => l.startsWith('DEL_ONION ')), false);
    await s3.close();

    expect(backend.starts, 3);
    expect(backend.stops, 3);
    await tor.stop();
    await dir.delete(recursive: true);
  });

  test('malformed input never reaches tor', () async {
    final tor = FakeTor('d');
    await tor.startTcp();
    final ctl = await TorControl.connectTcp('127.0.0.1', tor.server.port);
    await ctl.authenticate();
    expect(
        () => ctl.addOnion(
            privateKey: 'ED25519-V3:abc\r\nSETCONF Foo=1',
            virtualPort: 80,
            targetPort: 1),
        throwsA(isA<ArgumentError>()));
    expect(() => ctl.send('GETINFO x\r\nSETCONF y'),
        throwsA(isA<ArgumentError>()));
    expect(() => ctl.delOnion('not-an-id'), throwsA(isA<ArgumentError>()));
    await Future<void>.delayed(const Duration(milliseconds: 100));
    expect(tor.received.any((l) => l.contains('SETCONF')), false);
    await ctl.close();
    await tor.stop();
  });

  test('two messengers talk through TorSession + fake Tor + fake SOCKS5',
      () async {
    final socks = FakeSocks({});
    await socks.start();
    final ps = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    final qs = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    final pa = ps.port, pb = qs.port;
    await ps.close();
    await qs.close();

    final dirA = await tmp();
    final dirB = await tmp();
    final torA = FakeTor('a', socksPort: socks.server.port);
    final torB = FakeTor('b', socksPort: socks.server.port);
    await torA.startUnix('${dirA.path}/c.sock');
    await torB.startUnix('${dirB.path}/c.sock');
    socks.routes['${'a' * 56}.onion'] = pa;
    socks.routes['${'b' * 56}.onion'] = pb;

    final vaultA = await Vault.create(MemoryBlobStore(), 'pass-alice',
        params: Argon2Params.fastForTests);
    final vaultB = await Vault.create(MemoryBlobStore(), 'pass-bob',
        params: Argon2Params.fastForTests);
    final progressA = <int>[];
    final sa = await TorSession.start(
        backend: FakeBackend('${dirA.path}/c.sock'),
        vault: vaultA,
        listenPort: pa,
        onProgress: progressA.add);
    final sb = await TorSession.start(
        backend: FakeBackend('${dirB.path}/c.sock'),
        vault: vaultB,
        listenPort: pb);
    expect(progressA.last, 100);

    final alice = await GraffCore.open(
        vault: vaultA,
        transport: sa.transport,
        newIdentityName: 'Alice',
        flushEvery: const Duration(hours: 1));
    final bob = await GraffCore.open(
        vault: vaultB,
        transport: sb.transport,
        newIdentityName: 'Bob',
        flushEvery: const Duration(hours: 1));

    final cb = await alice.addContact(bob.myLink());
    final ca = await bob.addContact(alice.myLink());
    expect(cb.bundle.onion, '${'b' * 56}.onion:80');

    var got = bob.events.first.timeout(const Duration(seconds: 10));
    await alice.sendText(cb.id, 'привет через onion');
    expect((await got).message.text, 'привет через onion');
    got = alice.events.first.timeout(const Duration(seconds: 10));
    await bob.sendText(ca.id, 'и тебе');
    expect((await got).message.text, 'и тебе');

    // every connection went to the proxy by .onion hostname
    expect(socks.requestedHosts.every((h) => h.endsWith('.onion')), true);
    expect(socks.requestedHosts.isNotEmpty, true);

    await alice.close();
    await bob.close();
    await sa.close();
    await sb.close();
    await torA.stop();
    await torB.stop();
    await dirA.delete(recursive: true);
    await dirB.delete(recursive: true);
  });
}
