import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:graff/core/crypto/aead.dart';
import 'package:graff/core/crypto/bundle.dart';
import 'package:graff/core/crypto/identity.dart';
import 'package:graff/core/crypto/ratchet.dart';
import 'package:graff/core/crypto/x3dh.dart';

Uint8List b(String s) => Uint8List.fromList(utf8.encode(s));
String s(Uint8List b) => utf8.decode(b);

Future<(DoubleRatchet, DoubleRatchet)> pair() async {
  final alice = await Identity.generate('alice');
  final bob = await Identity.generate('bob');
  final bobBundle = ContactBundle.fromIdentity(bob);
  final aliceBundle = ContactBundle.fromIdentity(alice);
  expect(await bobBundle.verify(), isTrue);

  final hsA = await x3dhInitiate(me: alice, them: bobBundle);
  final hsB = await x3dhRespond(
      me: bob, initiator: aliceBundle, ekPub: hsA.ekPub!);
  expect(hsA.sk, hsB.sk);
  expect(hsA.ad, hsB.ad);

  final a = await DoubleRatchet.initSender(hsA.sk, hsA.ad, bob.spkPub);
  final bR = DoubleRatchet.initReceiver(
      hsB.sk, hsB.ad, bob.spkSeed, bob.spkPub);
  return (a, bR);
}

void main() {
  test('ping-pong with several ratchet turns', () async {
    final (a, bb) = await pair();
    for (var i = 0; i < 5; i++) {
      expect(s(await bb.decrypt(await a.encrypt(b('a$i')))), 'a$i');
      expect(s(await a.decrypt(await bb.encrypt(b('b$i')))), 'b$i');
    }
  });

  test('out-of-order and skipped messages', () async {
    final (a, bb) = await pair();
    final m0 = await a.encrypt(b('0'));
    final m1 = await a.encrypt(b('1'));
    final m2 = await a.encrypt(b('2'));
    expect(s(await bb.decrypt(m2)), '2');
    expect(s(await bb.decrypt(m0)), '0');
    expect(s(await bb.decrypt(m1)), '1');
  });

  test('replay is rejected', () async {
    final (a, bb) = await pair();
    final m = await a.encrypt(b('x'));
    await bb.decrypt(m);
    expect(() => bb.decrypt(m), throwsA(isA<DecryptionFailure>()));
  });

  test('tampering fails and leaves the session usable', () async {
    final (a, bb) = await pair();
    final m = await a.encrypt(b('hello'));
    final bad = Uint8List.fromList(m)..[m.length - 1] ^= 1;
    expect(() => bb.decrypt(bad), throwsA(isA<DecryptionFailure>()));
    expect(s(await bb.decrypt(m)), 'hello'); // state was not corrupted
  });

  test('state survives JSON round-trip', () async {
    final (a, bb) = await pair();
    await bb.decrypt(await a.encrypt(b('1')));
    final restored = DoubleRatchet.fromJson(bb.toJson());
    expect(s(await restored.decrypt(await a.encrypt(b('2')))), '2');
  });

  test('forged bundle signature is detected', () async {
    final bob = await Identity.generate('bob');
    final mallory = await Identity.generate('mallory');
    final fake = ContactBundle(
      name: 'bob',
      edPub: bob.edPub,
      xPub: mallory.xPub, // attacker swaps the DH key
      spkPub: mallory.spkPub,
      spkSig: bob.spkSig,
    );
    expect(await fake.verify(), isFalse);
  });
}
