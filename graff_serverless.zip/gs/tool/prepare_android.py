#!/usr/bin/env python3
"""Prepares the android/ folder created by `flutter create` for Tor.

Run from the project root, after:
    flutter create --org app.graff --project-name graff .

It fails loudly if an anchor is not found, so a build can never silently
come out without Tor. Safe to run twice.
"""
import glob
import os
import re
import sys

# Default 0.4.8.16: builds with the compileSdk Flutter already uses.
# 0.4.9.x ships a newer tor (security fixes) but its AAR metadata demands
# compileSdk 37.1; opt in with:  GRAFF_TOR_VERSION=0.4.9.14 python3 tool/prepare_android.py
TOR_VERSION = os.environ.get('GRAFF_TOR_VERSION', '0.4.8.16')
TOR = '"info.guardianproject:tor-android:%s"' % TOR_VERSION
CTL = '"info.guardianproject:jtorctl:0.4.5.7"'
GPMAVEN = 'https://raw.githubusercontent.com/guardianproject/gpmaven/master'
NEEDS_NEW_SDK = TOR_VERSION.startswith('0.4.9')
COMPILE_SDK = 37  # only used when NEEDS_NEW_SDK
MIN_SDK = 24      # tor-android requirement

def die(msg):
    print('ERROR:', msg)
    sys.exit(1)

def read(p):
    with open(p, encoding='utf-8') as f:
        return f.read()

def write(p, s):
    with open(p, 'w', encoding='utf-8') as f:
        f.write(s)

def find(*cands):
    for c in cands:
        if os.path.exists(c):
            return c
    return None

def kts(path):
    return path.endswith('.kts')

# ---- root build file: Guardian Project maven repo -------------------------
root = find('android/build.gradle.kts', 'android/build.gradle') or die('android/build.gradle(.kts) not found')
s = read(root)
if 'gpmaven' not in s:
    line = ('maven { url = uri("%s") }' if kts(root) else 'maven { url "%s" }') % GPMAVEN
    s2, n = re.subn(r'(allprojects\s*\{\s*repositories\s*\{)', r'\1\n        ' + line, s, count=1)
    if n != 1:
        die('allprojects { repositories { not found in ' + root)
    write(root, s2)
    print('patched', root, '(+ gpmaven)')
else:
    print('ok     ', root)

# ---- app build file: compileSdk, minSdk, dependencies, proguard ----------
app = find('android/app/build.gradle.kts', 'android/app/build.gradle') or die('android/app/build.gradle(.kts) not found')
s = read(app)
k = kts(app)

if NEEDS_NEW_SDK:
    s, n1 = re.subn(r'compileSdk(Version)?\s*=?\s*[^\n]+',
                    ('compileSdk = %d' if k else 'compileSdk %d') % COMPILE_SDK, s, count=1)
    if n1 != 1: die('compileSdk line not found in ' + app)
s, n2 = re.subn(r'minSdk(Version)?\s*=?\s*[^\n]+',
                ('minSdk = %d' if k else 'minSdk %d') % MIN_SDK, s, count=1)
if n2 != 1: die('minSdk line not found in ' + app)

if 'tor-android' not in s:
    s += '\ndependencies {\n    implementation(%s)\n    implementation(%s)\n}\n' % (TOR, CTL)

if 'proguard-rules.pro' not in s:
    rule = ('proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")'
            if k else
            "proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'")
    s, n = re.subn(r'(buildTypes\s*\{\s*(?:getByName\("release"\)|release)\s*\{)', r'\1\n            ' + rule, s, count=1)
    if n != 1:
        die('buildTypes { release { not found in ' + app)
write(app, s)
print('patched', app, '(tor-android %s, minSdk %d%s, proguard)' % (TOR_VERSION, MIN_SDK, ', compileSdk %d' % COMPILE_SDK if NEEDS_NEW_SDK else ''))

# ---- gradle.properties: allow a very new compileSdk -----------------------
gp = 'android/gradle.properties'
g = read(gp) if os.path.exists(gp) else ''
if NEEDS_NEW_SDK and 'suppressUnsupportedCompileSdk' not in g:
    g = g.rstrip('\n') + '\nandroid.suppressUnsupportedCompileSdk=%d\n' % COMPILE_SDK
    write(gp, g)
    print('patched', gp)

# ---- proguard rules -------------------------------------------------------
shutil_src = 'android_overlay/proguard-rules.pro'
write('android/app/proguard-rules.pro', read(shutil_src))
print('wrote   android/app/proguard-rules.pro')

# ---- MainActivity.kt: keep the generated package name ---------------------
mains = glob.glob('android/app/src/main/kotlin/**/MainActivity.kt', recursive=True)
if len(mains) != 1:
    die('expected exactly one generated MainActivity.kt, found %r' % mains)
pkg = re.search(r'^package\s+([\w.]+)', read(mains[0]), re.M)
if not pkg:
    die('package line not found in ' + mains[0])
src = read('android_overlay/MainActivity.kt')
src = re.sub(r'^package\s+[\w.]+', 'package ' + pkg.group(1), src, count=1, flags=re.M)
write(mains[0], src)
print('wrote  ', mains[0], '(package %s)' % pkg.group(1))

# ---- manifest -------------------------------------------------------------
man = 'android/app/src/main/AndroidManifest.xml'
m = read(man)
if 'android.permission.INTERNET' not in m:
    m = m.replace('<application', '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)
if 'allowBackup' not in m:
    m = m.replace('<application', '<application\n        android:allowBackup="false"\n        android:fullBackupContent="false"', 1)
if '<application' not in m or 'allowBackup="false"' not in m:
    die('manifest patch failed')
write(man, m)
print('patched', man, '(INTERNET, allowBackup=false)')

# ---- remove the sample test that refers to the template app ---------------
wt = 'test/widget_test.dart'
if os.path.exists(wt):
    os.remove(wt)
    print('removed', wt)

print('\nDone. Next: flutter pub get && flutter run --release')
